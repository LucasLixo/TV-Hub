// Api Movies & Serie
export const TMDB_KEY = "9bd0b9c5408935f36fb2c60e149f2779";
export const TMDB_HOST = "https://api.themoviedb.org/3";
export const TMDB_LANG = "pt";
export const TMDB_PATH_IMG = "https://image.tmdb.org/t/p";

// Vizer
export const VIZER_DOMAIN = "red";
export const VIZER_HOST = `https://vizerhd.${VIZER_DOMAIN}`;
export const VIZER_SEARCH = `${VIZER_HOST}/pesquisar/?p=`;

// Bluray
export const BLURAY_DOMAIN = "net";
export const BLURAY_HOST = `https://topfilmestorrent.${BLURAY_DOMAIN}/`;
export const BLURAY_SEARCH = `${BLURAY_HOST}?s=`;

// Services Movie
export const MOVIE_SERVICES = [
  {
    id: '0',
    name: 'Embedder',
    url: 'https://embedder.net/e/movie?imdb='
  },
  {
    id: '1',
    name: 'Warezcdn',
    url: 'https://embed.warezcdn.net/filme/'
  },
  /* {
    id: '1',
    name: 'Lapumba - DUB',
    url: 'https://lapumba.xyz/e/'
  }, */
];

// User Agent
export const USER_AGENT_IPHONE = `Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1`;
export const USER_AGENT_ANDROID = `Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36`;
export const USER_AGENT_WINDOWS = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
export const USER_AGENT_MOZILLA = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0";

// Genre Movie
export const MOVIE_GENRE = [
  {
    id: 12,
    name: "Aventura"
  },
  {
    id: 14,
    name: "Fantasia"
  },
  {
    id: 16,
    name: "Animação"
  },
  {
    id: 18,
    name: "Drama"
  },
  {
    id: 27,
    name: "Terror"
  },
  {
    id: 28,
    name: "Ação"
  },
  {
    id: 35,
    name: "Comédia"
  },
  {
    id: 36,
    name: "História"
  },
  {
    id: 37,
    name: "Faroeste"
  },
  {
    id: 53,
    name: "Thriller"
  },
  {
    id: 80,
    name: "Crime"
  },
  {
    id: 99,
    name: "Documentário"
  },
  {
    id: 878,
    name: "Ficção científica"
  },
  {
    id: 9648,
    name: "Mistério"
  },
  {
    id: 10402,
    name: "Música"
  },
  {
    id: 10749,
    name: "Romance"
  },
  {
    id: 10751,
    name: "Família"
  },
  {
    id: 10752,
    name: "Guerra"
  },
  {
    id: 10770,
    name: "Cinema TV"
  }
];
