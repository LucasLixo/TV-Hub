import React, { useEffect, useRef } from 'react';
import WebView from 'react-native-webview';

// Recursos
import {
    DS,
    USER_AGENT_WINDOWS
} from "../../../resources/Index";

const WebPlayer = ({ isUrl, setHandleErro }) => {
    const WebRef = useRef(null);

    useEffect(() => {
    }, []);

    return (
        <WebView
            ref={WebRef}
            source={{ uri: isUrl }}
            style={DS.WebView}
            // javaScript Enabled
            javaScriptEnabled={true}
            // javaScript Can Open Window
            javaScriptCanOpenWindowsAutomatically={false}
            setSupportMultipleWindows={false}
            // dom Storage Enabled
            domStorageEnabled={true}
            // scales Page To Fit
            scalesPageToFit={false}
            // on Error
            onError={(syntheticEvent) => setHandleErro(syntheticEvent.nativeEvent.description)}
            // start In Loading State
            startInLoadingState={false}
            // userAgent
            userAgent={USER_AGENT_WINDOWS}
            // allows Protected Media
            allowsProtectedMedia={true}
            allowsFullscreenVideo={true}
            // text size android
            textZoom={100}
            // force Dark
            forceDarkOn={true}
            // Downloads
            cacheMode='LOAD_DEFAULT'
            saveFormDataDisabled={false}
            allowFileAccess={false}
            // Icognito
            incognito={false}
            // Scrool
            overScrollMode='never'
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            // enable zoom
            setBuiltInZoomControls={false}
            // load media - always
            mixedContentMode='compatibility'
        />
    );
};

// Export
export default WebPlayer;