import React from 'react';
import {
    Text,
    View,
} from 'react-native';

// Recursos
import {
    DS
} from "../../../resources/Index";

const ActivityErro = ({ textError }) => {

    return (
        <View
            style={[DS.containerCenter, { width: '100%', height: '100%', position: 'absolute', zIndex: 10 }]}
        >
            <Text style={[DS.TextTitle, { fontSize: 22, textAlign: 'center', textTransform: 'uppercase' }]}>
                {`ERROR`}
            </Text>
            {textError && (
                <Text style={[DS.TextWhite, { fontSize: 12, textAlign: 'center', textTransform: 'uppercase' }]}>
                    {textError}
                </Text>
            )}
        </View>
    );
};

// Export
export default ActivityErro;