import React, { useRef } from 'react';
import WebView from 'react-native-webview';

// Recursos
import {
    DS,
    USER_AGENT_IPHONE
} from "../../../resources/Index";

const WebScraping = ({ isUrl, isInjectedJavaScript, setHandleMessage }) => {
    const WebRef = useRef(null);

    return (
        <WebView
            ref={WebRef}
            source={{ uri: isUrl }}
            style={DS.WebView}
            // javaScript Enabled
            javaScriptEnabled={true}
            // javaScript Can Open Window
            javaScriptCanOpenWindowsAutomatically={false}
            setSupportMultipleWindows={false}
            // dom Storage Enabled
            domStorageEnabled={true}
            // scales Page To Fit
            scalesPageToFit={false}
            // on Error
            // onError={(syntheticEvent) => setHandleErro(syntheticEvent.nativeEvent.description)}
            injectedJavaScript={isInjectedJavaScript}
            onMessage={setHandleMessage}
            // start In Loading State
            startInLoadingState={false}
            // userAgent
            userAgent={USER_AGENT_IPHONE}
            // allows Protected Media
            allowsProtectedMedia={true}
            allowsFullscreenVideo={true}
            // text size android
            textZoom={100}
            // Downloads
            cacheMode='LOAD_DEFAULT'
            saveFormDataDisabled={false}
            allowFileAccess={false}
            // Icognito
            incognito={false}
            // load media - always
            mixedContentMode='compatibility'
        />
    );
};

// Export
export default WebScraping;