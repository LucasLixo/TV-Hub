import React from 'react';
import {
    View,
    Pressable,
    Text,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Components
import GradientHover from './GradientHover';

// Recursos
import {
    DS,
    Colors,
    IconsStyle
} from "../../../resources/Index";

const HeaderTop = ({ type }) => {
    const navigation = useNavigation();

    const goToSearchScreen = () => {
        navigation.navigate('Search', { type: type });
    };

    const goToConfigScreen = () => {
        navigation.navigate('Config');
    };

    return (
        <>
            <View style={[DS.ModalContentInput, { justifyContent: 'flex-end' }]}>
                <Text style={{
                    flex: 1, 
                    color: Colors.sky.a, 
                    paddingHorizontal: 10, 
                    textAlignVertical: 'center', 
                    fontWeight: 'bold',
                    fontSize: 18
                }}>
                    {`TV Hub`}
                </Text>
                <Pressable
                    style={[DS.ContentButton, { marginRight: 10 }]}
                    onPress={() => goToSearchScreen()}
                >
                    <IconsStyle name="search" size={38} color={Colors.sky.a} />
                </Pressable>
                <Pressable
                    style={DS.ContentButton}
                    onPress={() => goToConfigScreen()}
                >
                    <IconsStyle name="config" size={36} color={Colors.sky.a} />
                </Pressable>
                <GradientHover type='top' size={-10} />
            </View>
            {/* <GradientHover type='bottom' size={0} /> */}
        </>
    );
};

// Export
export default HeaderTop;
