import React from "react";
import {
    Linking,
    Modal,
    Pressable,
    ImageBackground as RNImage,
} from "react-native";

// Recursos
import {
    DS,
    clipboardToast
} from "../../../resources/Index";

const ModalToastImage = ({ isModalVisible, setModalVisible, imageURL }) => {
    const handleClose = () => {
        setModalVisible();
    };

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={DS.ModalContentShadow}
                onPress={() => handleClose()}
            >
                <Pressable
                    style={{ width: '50%', height: '35%', borderRadius: 10, overflow: 'hidden', transform: [{ scale: 1.3 }] }}
                    onPress={() => Linking.openURL(imageURL || '')}
                    onLongPress={() => clipboardToast(imageURL || '')}
                >
                    <RNImage
                        style={{ width: '100%', height: '100%' }}
                        source={{ uri: imageURL }}
                    >
                    </RNImage>
                </Pressable>
            </Pressable>
        </Modal>
    );
};

export default ModalToastImage;
