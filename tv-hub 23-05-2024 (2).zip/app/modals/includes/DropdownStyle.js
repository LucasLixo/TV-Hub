import { StyleSheet } from 'react-native';

// Recursos
import { Colors } from "../../../resources/Index";

const Styles = StyleSheet.create({
    contentDropdown: {
        width: '100%', 
        height: 'auto', 
        overflow: 'hidden'
    },
    titleDropdown: {
        textAlign: 'center', 
        backgroundColor: Colors.sky.b, 
        borderTopLeftRadius: 15, 
        borderTopRightRadius: 15,
        borderBottomColor: Colors.gray.b,
        borderBottomWidth: 1,
        paddingVertical: 5,
        marginBottom: 0
    },
    textDropdown: {
        width: '100%',
        textAlign: 'center',
        fontSize: 14,
        fontWeight: 'bold',
        paddingVertical: 10,
        backgroundColor: Colors.gray.a,
        borderBottomColor: Colors.gray.b,
        borderBottomWidth: 1,
        color: Colors.white.a,
    },
});

// Export
export default Styles;