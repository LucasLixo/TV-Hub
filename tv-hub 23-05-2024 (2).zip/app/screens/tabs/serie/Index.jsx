import React from 'react';
import {
    View,
    Text,
} from 'react-native';

// Recursos
import {
    DS,
} from "../../../../resources/Index";

// Components
import {
    HeaderTop,
    Footer
} from "../../../components/Index";

const Series = () => {

    return (
        <>
            <HeaderTop type='Serie' />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Série`}</Text>
                <Footer />
            </View>
        </>
    );
};

// Export
export default Series;