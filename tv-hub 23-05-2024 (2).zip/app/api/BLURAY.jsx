import React, { useEffect, useState } from "react";
import { View } from "react-native";

// Recursos
import {
    encodeWithPlus,
    verifyUrl,
    BLURAY_SEARCH
} from "../../resources/Index";

// Components
import { 
    WebScraping
} from "../components/Index";

export const LinkMoviesToBluray = ({ search, setLinksArray }) => {
    const [extractedHref01, setExtractedHref01] = useState(null);
    const [extractedHref02, setExtractedHref02] = useState(null);

    const url = `${BLURAY_SEARCH}${encodeWithPlus(search)}`;
    
    useEffect(() => {
        if (verifyUrl(extractedHref02)) {
            setLinksArray([
                {
                    id: '5',
                    name: 'Bluray',
                    url: extractedHref02
                },
            ]);
        }
    }, [extractedHref02]);

    const injectedJavaScript01 = `
    setTimeout(() => {
        const linkElement = document.querySelector("html > body > div#container > div#main > div#content > article > header.entry-header.cf > h2.entry-title > a[href]");
        if (linkElement) {
            window.ReactNativeWebView.postMessage(linkElement.href);
        } else {
            window.ReactNativeWebView.postMessage("Not Found");
        }
    }, 1000);
    true;
    `;

    const injectedJavaScript02 = `
    setTimeout(() => {
        const linkElement = document.querySelector("html > body > div#container > div#main > div#content > article > div.entry-content.cf > p > a[href] > img.alignnone.size-full.wp-image-177776.aligncenter");
        if (linkElement) {
            window.ReactNativeWebView.postMessage(linkElement.parentElement.href);
        } else {
            window.ReactNativeWebView.postMessage("Not Found");
        }
    }, 1000);
    true;
    `;

    // const setLinksArray = (linksArray) => {
    //     console.log(linksArray);
    // }

    return (
        <View style={{ flex: 0, width: '0%', height: '0%' }}>
            {url && (
                <>
                    <WebScraping
                        isUrl={url}
                        isInjectedJavaScript={injectedJavaScript01}
                        setHandleMessage={(event) => setExtractedHref01(event.nativeEvent.data)}
                    />
                    {extractedHref01 && extractedHref01 !== 'Not Found' && (
                        <WebScraping
                            isUrl={extractedHref01}
                            isInjectedJavaScript={injectedJavaScript02}
                            setHandleMessage={(event) => setExtractedHref02(event.nativeEvent.data)}
                        />
                    )}
                </>
            )}
        </View>
    );
}
