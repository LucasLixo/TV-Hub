import React, { useEffect, useReducer, useState } from 'react';
import WebScraping from '../components/web/WebScraping';
import HeaderSearch from './includes/HeaderSearch';
import { View, ScrollView, Pressable } from 'react-native';
import { encodeWithPlus } from '../hooks/Fuctions';
import { GENRES, VIZER_SEARCH } from '../hooks/Constants';
import ActivityTemp from '../components/ActivityTemp';
import { useNavigation } from '@react-navigation/native';
import { SCRIPT_NEW_MOVIES, SCRIPT_PAGES } from '../hooks/Scripts';
import Styles from '../hooks/Styles';
import FlatlistVertical from '../components/FlatlistVertical';
import MyText from '../components/MyText';
import Colors from '../hooks/Colors';

const reducer = (state, action) => {
    switch (action.type) {
        case 'preview':
            return { ...state, Page: Math.max(state.Page - 1, 1) };
        case 'next':
            return { ...state, Page: state.Page + 1 };
        case 'setTotalPage':
            return { ...state, TotalPage: action.payload };
        default:
            return state;
    }
};

const Search = () => {
    const navigation = useNavigation();

    const [isString, setString] = useState('');
    const [isResults, setResults] = useState([]);
    const [isStringSearch, setStringSearch] = useState('');

    const [state, dispatch] = useReducer(reducer, {
        TotalPage: null,
        Page: 1,
    });

    const searchUrl = `${VIZER_SEARCH}${isStringSearch}&page=${state.Page}`;

    useEffect(() => {
        setStringSearch(encodeWithPlus(isString));
    }, [isString]);

    return (
        <ScrollView style={Styles.ContainerView}>
            <HeaderSearch setStringSearch={setString} />
            {isStringSearch ? (
                <>
                    <WebScraping
                        isUrl={searchUrl}
                        isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                        setHandleMessage={(results) => {
                            setResults(JSON.parse(results));
                        }}
                    />
                    <WebScraping
                        isUrl={`${VIZER_SEARCH}${isStringSearch}`}
                        isInjectedJavaScript={SCRIPT_PAGES}
                        setHandleMessage={(results) => {
                            console.log(results);
                            dispatch({ type: 'setTotalPage', payload: parseInt(results) });
                        }}
                    />
                    {isResults.length === 0 && (
                        <View style={{ width: '100%', height: '100%', position: 'relative' }}>
                            <ActivityTemp />
                        </View>
                    )}
                    {isResults.length > 0 && state.TotalPage !== null && (
                        <>
                            <View style={[Styles.Header, { paddingHorizontal: 10 }]}>
                                {state.Page !== 1 && (
                                    <Pressable
                                        style={Styles.ButtonPage}
                                        onPress={() => dispatch({ type: 'preview' })}
                                    >
                                        <MyText type='topic'>
                                            {`Anterior`}
                                        </MyText>
                                    </Pressable>
                                )}
                                <MyText type='topic'>{`Páginas: ${state.TotalPage}`}</MyText>
                                {state.Page !== state.TotalPage && (
                                    <Pressable
                                        style={Styles.ButtonPage}
                                        onPress={() => dispatch({ type: 'next' })}
                                    >
                                        <MyText type='topic'>
                                            {`Próximo`}
                                        </MyText>
                                    </Pressable>
                                )}
                            </View>
                            <View style={Styles.Hr} />
                            <FlatlistVertical data={isResults} />
                        </>
                    )}
                </>
            ) : (
                <View style={{ width: '100%', flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' }}>
                    {GENRES.map(({ key, title, url }) => (
                        <Pressable 
                            key={key} 
                            style={{
                                width: '40%',
                                height: 50,
                                backgroundColor: Colors.sky.b,
                                margin: 10,
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRadius: 10
                            }}
                            onPress={() => navigation.navigate('ResultsGenre', { title, url })}
                        >
                            <MyText type='topic' style={{ textTransform: 'capitalize' }}>
                                {title}
                            </MyText>
                        </Pressable>
                    ))}
                </View>
            )}
        </ScrollView>
    );
};

// Export
export default Search;
