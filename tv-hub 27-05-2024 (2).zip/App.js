import React, { useEffect, useState } from 'react';
import { AppRegistry } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';
import NetInfo from '@react-native-community/netinfo';

import Colors from './hooks/Colors';
import Styles from './hooks/Styles';

import Movie from './screens/Movie';
import Config from './screens/Config';
import Search from './screens/Search';
import PlayerVideo from './screens/PlayerVideo';
import ResultsGenre from './screens/ResultsGenre';
import DetailsMovie from './screens/DetailsMovie';
import Comments from './screens/Comments';
import ActivityErro from './components/ActivityErro';

const Stack = createStackNavigator();

const navTheme = {
    colors: {
        background: Colors.background.a,
    },
};

function App() {
    const [isConnected, setIsConnected] = useState(true);

    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener(state => {
            setIsConnected(state.isConnected);
            // setIsConnected(false);
        });

        return () => {
            unsubscribe();
        };
    }, []);

    return isConnected ? (
        <NavigationContainer theme={navTheme}>
            <SafeAreaView style={Styles.AreaView} >
                <StatusBar
                    backgroundColor={Colors.background.a}
                />
                <Stack.Navigator
                    screenOptions={{
                        headerShown: false,
                        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                    }}
                    initialRouteName='Movie'
                >
                    <Stack.Screen name="Movie" component={Movie} />
                    {/* Configurações */}
                    <Stack.Screen name="Config" component={Config} />
                    {/* Pesquisa */}
                    <Stack.Screen name="Search" component={Search} />
                    {/* */}
                    <Stack.Screen name="PlayerVideo" component={PlayerVideo} />
                    <Stack.Screen name="DetailsMovie" component={DetailsMovie} />
                    <Stack.Screen name="ResultsGenre" component={ResultsGenre} />
                    <Stack.Screen name="Comments" component={Comments} />
                </Stack.Navigator>
            </SafeAreaView>
        </NavigationContainer>
    ) : (
        <SafeAreaView style={Styles.AreaView} >
            <StatusBar
                backgroundColor={Colors.background.a}
            />
            <ActivityErro textError='SEM CONEXÃO COM A INTERNET' />
        </SafeAreaView>
    );
}

// Registrar o componente App
AppRegistry.registerComponent('App', () => App);

// Exportar o componente App
export default App;
