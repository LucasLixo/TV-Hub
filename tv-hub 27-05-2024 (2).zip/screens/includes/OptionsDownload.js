import React from 'react';
import { View } from 'react-native';

const OptionsDownload = () => {
    return (
        <View>
        </View>
    );
};

// Export
export default OptionsDownload;