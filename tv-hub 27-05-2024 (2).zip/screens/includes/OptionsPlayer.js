import React from 'react';
import { Pressable, View } from 'react-native';
import { clipboardToast, extractUrlVizer } from '../../hooks/Fuctions';
import { useNavigation } from '@react-navigation/native';
import ShowModalFade from '../../components/ShowModalFade';
import Styles from '../../hooks/Styles';
import MyText from '../../components/MyText';
import Colors from '../../hooks/Colors';

const OptionsPlayer = ({ isModalVisible, setModalVisible, url }) => {
    const navigation = useNavigation();

    const extractedUrl = extractUrlVizer(url);

    const handleNavigate = (service) => {
        setModalVisible(!isModalVisible);
        console.log(`${extractedUrl}&sv=${service}`);
        navigation.navigate('PlayerVideo', {
            url: `${extractedUrl}&sv=${service}`,
            service: service
        })
    }

    return (
        <ShowModalFade isModalVisible={isModalVisible} setModalVisible={setModalVisible}>
            <View style={{ width: '100%', padding: 10, borderRadius: 10, backgroundColor: Colors.gray.b }}>
                <MyText type='topic' style={{ marginBottom: 10, fontSize: 16, color: Colors.text.b }}>
                    {`Players`}
                </MyText>
                <View style={{ width: '100%', padding: 5, borderRadius: 10, backgroundColor: Colors.gray.c }}>
                    <Pressable
                        style={{ width: '100%', height: 30, alignItems: 'center', justifyContent: 'center' }}
                        onLongPress={() => clipboardToast(`${extractedUrl}&sv=mixdrop`)}
                        onPress={() => handleNavigate('mixdrop')}
                    >
                        <MyText type='topic' style={{ fontSize: 18, color: Colors.text.a }}>{`Mixdrop`}</MyText>
                    </Pressable>
                    <View style={Styles.Hr} />
                    <Pressable
                        style={{ width: '100%', height: 30, alignItems: 'center', justifyContent: 'center' }}
                        onLongPress={() => clipboardToast(`${extractedUrl}&sv=filemoon`)}
                        onPress={() => handleNavigate('filemoon')}
                    >
                        <MyText type='topic' style={{ fontSize: 18, color: Colors.text.a }}>{`Filemoon`}</MyText>
                    </Pressable>
                    <View style={Styles.Hr} />
                    <Pressable
                        style={{ width: '100%', height: 30, alignItems: 'center', justifyContent: 'center' }}
                        onLongPress={() => clipboardToast(`${extractedUrl}&sv=streamtape`)}
                        onPress={() => handleNavigate('streamtape')}
                    >
                        <MyText type='topic' style={{ fontSize: 18, color: Colors.text.a }}>{`Streamtape`}</MyText>
                    </Pressable>
                </View>
            </View>
        </ShowModalFade>
    );
};

// Export
export default OptionsPlayer;