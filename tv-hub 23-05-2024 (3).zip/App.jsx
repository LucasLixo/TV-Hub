import React, { useEffect, useState } from 'react';
import { AppRegistry } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';
import NetInfo from '@react-native-community/netinfo';

// Recursos
import { 
    Colors,
    IconsStyle
} from './resources/Index';

// Components
import { 
    ActivityErro 
} from "./app/components/Index";

// Tabs
import channel from './app/screens/tabs/channel/Index';
import Movie from './app/screens/tabs/movie/Index';
import Serie from './app/screens/tabs/serie/Index';

// Telas
import Config from './app/screens/config/Index';
import ScreenSearch from './app/screens/search/Search';
import ScreenSearchGenre from './app/screens/search/SearchGenre';
import DetailsMovie from './app/screens/tabs/movie/Details';
import PlayerVideo from './app/screens/player/Index';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const navTheme = {
    colors: {
        background: Colors.black.a,
    },
};

function BottomTabs() {
    return (
        <Tab.Navigator
            initialRouteName='Filmes'
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;

                    if (route.name === 'channels') {
                        iconName = focused ? 'pause' : 'play';
                    } else if (route.name === 'Filmes') {
                        iconName = focused ? 'pause' : 'play';
                    } else if (route.name === 'Series') {
                        iconName = focused ? 'pause' : 'play';
                    }

                    return <IconsStyle name={iconName} size={26} color={Colors.sky.a} />;
                },
                headerShown: false,
                tabBarActiveTintColor: Colors.sky.a,
                tabBarInactiveTintColor: Colors.white.a,
                tabBarLabelStyle: {
                    fontWeight: 'bold',
                },
                tabBarStyle: {
                    height: 50,
                },
            })}
        >
            <Tab.Screen name="Series" component={Serie} />
            <Tab.Screen name="Filmes" component={Movie} />
            <Tab.Screen name="Channels" component={channel} />
        </Tab.Navigator>
    );
}

function App() {
    const [isConnected, setIsConnected] = useState(true);

    useEffect(() => {
        const unsubscribe = NetInfo.addEventListener(state => {
            setIsConnected(state.isConnected);
            // setIsConnected(false);
        });

        return () => {
            unsubscribe();
        };
    }, []);

    return isConnected ? (
        <NavigationContainer theme={navTheme}>
            <SafeAreaView
                style={{
                    flex: 1,
                    width: '100%',
                    height: '100%',
                    position: 'relative',
                }}
            >
                <Stack.Navigator
                    screenOptions={{
                        // headerMode: 'screen',
                        headerShown: false,
                        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                    }}
                    initialRouteName='Filmes'
                >
                    <Stack.Screen name="Filmes" component={Movie} />
                    {/* <Stack.Screen name="Main" component={BottomTabs} /> */}
                    {/* Configurações */}
                    <Stack.Screen name="Config" component={Config} />
                    {/* Pesquisa */}
                    <Stack.Screen name="Search" component={ScreenSearch} />
                    <Stack.Screen name="SearchGenre" component={ScreenSearchGenre} />
                    {/* Details */}
                    <Stack.Screen name="DetailsMovie" component={DetailsMovie} />
                    {/* Player */}
                    <Stack.Screen name="PlayerVideo" component={PlayerVideo} />
                </Stack.Navigator>
            </SafeAreaView>
        </NavigationContainer>
    ) : (
        <SafeAreaView style={{ flex: 1, position: 'relative' }}>
            <ActivityErro textError='SEM CONEXÃO COM A INTERNET' />
        </SafeAreaView>
    );
}

// Registrar o componente App
AppRegistry.registerComponent('App', () => App);

// Exportar o componente App
export default App;
