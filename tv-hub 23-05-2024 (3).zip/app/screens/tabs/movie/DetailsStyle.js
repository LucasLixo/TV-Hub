import { StyleSheet } from 'react-native';

// Recursos
import { Colors } from "../../../../resources/Index";

const Styles = StyleSheet.create({
    ImageBackdrop: {
        width: '100%',
        height: 200,
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'flex-start'
    },
    Image: {
        width: 140,
        height: 200,
        borderRadius: 10,
    },
    TextTitle:{
        textAlign: 'center',
        fontSize: 14,
        fontWeight: 'bold',
        color: Colors.white.a,
        marginBottom: 10,
    },
    TextInfo: {
        textAlign: 'center',
        fontSize: 10,
        color: Colors.gray.d,
    },
    ViewHr: {
        marginVertical: 10,
        // borderTopColor: Colors.gray.e,
        // borderTopWidth: 1,
    },
    TextOverview: {
        textAlign: 'center',
        fontSize: 12,
        color: Colors.gray.d,
    },
    ButtonPlay: {
        position: 'relative',
        marginHorizontal: 'auto',
        width: '90%',
        paddingVertical: 5,
        backgroundColor: Colors.sky.b,
        flexDirection: 'row',
        justifyContent: 'center',
        borderRadius: 10
    },
    ButtonPlayText: {
        color: Colors.white.a,
        fontSize: 14,
        textTransform: 'capitalize'
    },
    ContentDropdown: {
        width: '90%', 
        marginHorizontal: 'auto', 
        flexDirection: 'row', 
        alignItems: 'center', 
        justifyContent: 'space-between',
    },
});

// Export
export default Styles;