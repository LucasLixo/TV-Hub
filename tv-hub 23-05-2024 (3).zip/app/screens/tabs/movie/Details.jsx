import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import Styles from './DetailsStyle';

// Api
import { getMovieByIdApi } from '../../../api/TMDB';
import { LinkMoviesToVizer } from '../../../api/VIZER';
import { LinkMoviesToBluray } from '../../../api/BLURAY';

// Modals
import {
    ModalToastMessage,
    ModalToastImage,
    ModalDropdown,
} from '../../../modals/Index';

// Recursos
import {
    DS,
    TMDB_PATH_IMG,
    MOVIE_SERVICES,
    IconsStyle,
    Colors,
    clipboardToast,
} from "../../../../resources/Index";

// Components
import {
    HeaderIcon,
    ActivityTemp
} from "../../../components/Index";

const DetailsMovie = () => {
    const route = useRoute();
    const { idMovie } = route.params;

    const navigation = useNavigation();

    const navigateByGenre = (genre) => {
        navigation.navigate('SearchGenre', {
            dataGenre: {
                Type: 'Movie',
                Id: genre.id,
                Name: genre.name,
            }
        });
    };

    const [DetailsMovie, setDetailsMovie] = useState(null);
    const [isModalToastMessage, setModalToastMessage] = useState(false);
    const [isModalToastImage, setModalToastImage] = useState(false);
    const [isModalDropdown, setModalDropdown] = useState(false);

    const [isServices, setServices] = useState(MOVIE_SERVICES);
    const [isSelectedServiceName, setSelectedServiceName] = useState(isServices[0].name);
    const [SelectedServicesId, setSelectedServicesId] = useState(isServices[0].id);

    const [infoAbout, setInfoAbout] = useState("");

    const fetchMovies = async () => {
        try {
            const data = await getMovieByIdApi(idMovie);
            setDetailsMovie(data);
            setInfoAbout(`IMDB: ${data.imdb_id}\nTMDB: ${data.id}`);
        } catch (error) {
            console.error("Error fetching movie details: ", error);
        }
    };

    useEffect(() => {
        fetchMovies();
    }, [idMovie]);

    useEffect(() => {
        console.log(isServices);
    }, [isServices]);

    const handleSetLinksArray = (results) => {
        setServices(prevServices => {
            const newServices = results.filter(result =>
                !prevServices.some(service => service.id === result.id)
            );
            return [...prevServices, ...newServices];
        });
    };

    useEffect(() => {
        setSelectedServiceName(isServices[SelectedServicesId].name);
    }, [SelectedServicesId]);

    const playerMovie = () => {
        if (!DetailsMovie) return;
        let Url;
        switch (SelectedServicesId) {
            case '0':
            case '1':
                Url = `${isServices[SelectedServicesId].url}${DetailsMovie.imdb_id}`;
                break;
            default:
                Url = `${isServices[SelectedServicesId].url}`;
                break;
        }
        navigation.navigate('PlayerVideo', { uriLoad: Url });
    };

    return (
        <>
            {infoAbout && <HeaderIcon icon='about' text={infoAbout} />}
            {DetailsMovie ? (
                <View style={DS.containerB}>
                    <LinkMoviesToVizer
                        search={DetailsMovie.title || DetailsMovie.original_title}
                        setLinksArray={(results) => handleSetLinksArray(results)}
                    />
                    <LinkMoviesToBluray
                        search={DetailsMovie.title || DetailsMovie.original_title}
                        setLinksArray={(results) => handleSetLinksArray(results)}
                    />
                    <View style={Styles.ImageBackdrop}>
                        {DetailsMovie.poster_path ? (
                            <Pressable onPress={() => setModalToastImage(!isModalToastImage)}>
                                <Image
                                    source={{ uri: `${TMDB_PATH_IMG}/w780${DetailsMovie.poster_path}` }}
                                    style={Styles.Image}
                                />
                            </Pressable>
                        ) : (
                            <View style={[Styles.Image, { backgroundColor: Colors.gray.b }]} />
                        )}
                        <View style={{ width: '50%', height: '100%' }}>
                            <Pressable onLongPress={() => clipboardToast(DetailsMovie.title || DetailsMovie.original_title)}>
                                <Text style={Styles.TextTitle} numberOfLines={3} ellipsizeMode='tail'>
                                    {DetailsMovie.title || DetailsMovie.original_title}
                                </Text>
                            </Pressable>
                            <Pressable onLongPress={() => clipboardToast(DetailsMovie.release_date)}>
                                <Text style={Styles.TextInfo} numberOfLines={1} ellipsizeMode='tail'>
                                    {`Lançamento: ${DetailsMovie.release_date}`}
                                </Text>
                            </Pressable>
                            {DetailsMovie.tagline && (
                                <>
                                    <View style={Styles.ViewHr} />
                                    <Text style={Styles.TextInfo} numberOfLines={2} ellipsizeMode='tail'>
                                        {DetailsMovie.tagline}
                                    </Text>
                                </>
                            )}
                        </View>
                    </View>
                    {DetailsMovie.genres && (
                        <>
                            <View style={Styles.ViewHr} />
                            <View style={{
                                width: '95%', // 10
                                marginLeft: '5%'
                            }}>
                                <FlatList
                                    data={DetailsMovie.genres}
                                    keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
                                    horizontal={true}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item }) => (
                                        <Pressable
                                            style={{
                                                paddingHorizontal: 10,
                                                paddingVertical: 5,
                                                borderRadius: 10,
                                                marginRight: 10,
                                                backgroundColor: Colors.sky.b,
                                            }}
                                            onPress={() => navigateByGenre(item)}
                                        >
                                            <Text style={{
                                                color: Colors.white.a,
                                                fontSize: 14,
                                                textTransform: 'capitalize',
                                                fontWeight: 'bold',
                                            }}>
                                                {item.name}
                                            </Text>
                                        </Pressable>
                                    )}
                                />
                            </View>
                        </>

                    )}
                    <View style={Styles.ViewHr} />
                    <View style={Styles.ContentDropdown}>
                        <Text style={Styles.TextOverview}>{`Servidor`}</Text>
                        <Pressable
                            style={[Styles.ButtonPlay, { marginHorizontal: 0, width: '50%', backgroundColor: Colors.gray.c, justifyContent: 'space-around' }]}
                            onPress={() => setModalDropdown(!isModalDropdown)}
                        >
                            <Text style={{ color: Colors.white.a, fontWeight: 'bold' }}>
                                {isSelectedServiceName}
                            </Text>
                        </Pressable>
                    </View>
                    <View style={Styles.ViewHr} />
                    <Pressable
                        style={Styles.ButtonPlay}
                        onPress={() => playerMovie()}
                    >
                        <>
                            <IconsStyle name='play' size={26} color={Colors.white.a} />
                            <Text style={{ color: Colors.white.a, fontWeight: 'bold' }}>{`  Play`}</Text>
                        </>
                    </Pressable>
                    {DetailsMovie.overview && (
                        <>
                            <View style={Styles.ViewHr} />
                            <Pressable
                                onPress={() => setModalToastMessage(!isModalToastMessage)}
                            >
                                <Text style={Styles.TextOverview} numberOfLines={5} ellipsizeMode='tail'>
                                    {`Sinopse: ${DetailsMovie.overview}`}
                                </Text>
                            </Pressable>
                        </>
                    )}
                </View>
            ) : (
                <ActivityTemp />
            )}
            <ModalDropdown
                isModalVisible={isModalDropdown}
                setModalVisible={() => setModalDropdown(!isModalDropdown)}
                dataArray={isServices}
                onSelectItem={(itemId) => setSelectedServicesId(itemId)}
            />
            <ModalToastMessage
                isModalVisible={isModalToastMessage}
                setModalVisible={() => setModalToastMessage(!isModalToastMessage)}
                Message={DetailsMovie ? `Sinopse: ${DetailsMovie.overview}` : ''}
            />
            {DetailsMovie?.poster_path && (
                <ModalToastImage
                    isModalVisible={isModalToastImage}
                    setModalVisible={() => setModalToastImage(!isModalToastImage)}
                    imageURL={`${TMDB_PATH_IMG}/w1280${DetailsMovie.poster_path}`}
                />
            )}
        </>
    );
};

// Export
export default DetailsMovie;
