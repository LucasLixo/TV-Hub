import React, { useState } from 'react';
import { 
    Pressable 
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useRoute } from '@react-navigation/native';

// Recursos
import {
    DS,
    clipboardToast,
    OrientationAllow,
} from "../../../resources/Index";

// Components
import {
    ActivityErro,
    WebPlayer ,
} from '../../components/Index';

const PlayerVideo = () => {
    const [loadingError, setLoadingError] = useState(false);
    const [textError, setTextError] = useState(null);

    const route = useRoute();
    const { uriLoad } = route.params;

    OrientationAllow();

    const handleErroStateChange = (errorMessage) => {
        setLoadingError(true);
        setTextError(errorMessage);
    };

    return (
        <Pressable
            style={[DS.WebView, { position: 'relative' }]}
            onLongPress={() => clipboardToast(uriLoad)}
        >
            <StatusBar
                animated={true}
                backgroundColor='transparent'
                hidden={true}
            />
            <WebPlayer isUrl={uriLoad} setHandleErro={handleErroStateChange} />
            {loadingError && (
                <ActivityErro textError={textError} />
            )}
        </Pressable>
    );
};

// Export
export default PlayerVideo;
