import React, { useEffect, useState } from 'react';
import {
    Text,
    Pressable,
    View,
} from 'react-native';
import { useRoute } from '@react-navigation/native';

// Api
import { getGenreMoviesApi } from '../../api/TMDB';

// Recursos
import {
    DS,
    Colors,
    IconsStyle,
} from "../../../resources/Index";

// Components
import {
    GradientHover,
    FlatlistVertical,
    HeaderTitle,
    ActivityTemp,
} from '../../components/Index';

const ScreenSearchGenre = () => {
    const route = useRoute();
    const { dataGenre } = route.params;

    const [results, setResults] = useState(null);
    const [totalPages, setTotalPages] = useState(null);
    const [page, setPage] = useState(1);

    const fetchMovies = async () => {
        let data;
        switch (dataGenre.Type) {
            case 'Movie':
                data = await getGenreMoviesApi(dataGenre.Id, page);
                break;
            case 'Serie':
                data = await getGenreMoviesApi(dataGenre.Id, page);
                break;
            case 'Anime':
                data = await getGenreMoviesApi(dataGenre.Id, page);
                break;
        }

        setResults(data.results);
        setTotalPages(data.total_pages);
        setPage(data.page);
    }

    useEffect(() => {
        if (dataGenre) {
            fetchMovies();
        }
    }, [dataGenre, page]);

    const fetchBackPage = () => {
        setPage(prevPage => Math.max(prevPage - 1, 1));
    }

    const fetchNextPage = () => {
        setPage(prevPage => Math.min(prevPage + 1, totalPages));
    }

    return (
        <View style={{ flex: 1, alignItems: 'center' }}>
            {results ? (
                <>
                    <HeaderTitle title={dataGenre.Name || ''} />
                    <FlatlistVertical data={results} />
                    <View style={{ width: '100%', position: 'relative' }}>
                        <View style={[DS.ModalContentInput, { height: 50 }]} >
                            <Text style={{ fontSize: 20, color: Colors.gray.b }}>{`0`}</Text>
                            <Pressable
                                style={{ backgroundColor: Colors.sky.b, borderRadius: 10 }}
                                onPress={() => fetchBackPage()}
                            >
                                <IconsStyle name="arrowLeft" size={48} color={Colors.white.a} />
                            </Pressable>
                            <Text style={{ fontSize: 24, color: Colors.sky.b }}>{page}</Text>
                            <Pressable
                                style={{ backgroundColor: Colors.sky.b, borderRadius: 10 }}
                                onPress={() => fetchNextPage()}
                            >
                                <IconsStyle name="arrowRight" size={48} color={Colors.white.a} />
                            </Pressable>
                            <Text style={{ fontSize: 20, color: Colors.gray.b }}>{totalPages}</Text>
                        </View>
                        <GradientHover type='bottom' size={50} />
                    </View>
                </>
            ) : (
                <ActivityTemp />
            )}
        </View>
    );
};

// Export
export default ScreenSearchGenre;
