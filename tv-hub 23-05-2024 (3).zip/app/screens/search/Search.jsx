import React, { useEffect, useState } from 'react';
import {
    Text,
    Pressable,
    TextInput,
    FlatList,
    View,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import Styles from './SearchStyle';

// Api
import { searchMoviesApi } from '../../api/TMDB';

// Recursos
import {
    DS,
    MOVIE_GENRE,
    Colors,
    IconsStyle
} from "../../../resources/Index";

// Componentes
import {
    FlatlistVertical,
    GradientHover,
} from '../../components/Index';

const ScreenSearch = () => {
    const route = useRoute();
    const { type } = route.params;
    const navigation = useNavigation();

    const goToBack = () => {
        navigation.goBack();
    };
    const navigateByGenre = (genre) => {
        navigation.navigate('SearchGenre', {
            dataGenre: {
                Type: 'Movie',
                Id: genre.id,
                Name: genre.name,
            }
        });
    };

    const [stringSearch, setStringSearch] = useState('');
    const [results, setResults] = useState(null);
    const [totalPages, setTotalPages] = useState(null);
    const [page, setPage] = useState(1);

    const fetchMovies = async () => {
        let data;
        switch (type) {
            case 'Movie':
                data = await searchMoviesApi(stringSearch, page);
                break;
            case 'Serie':
                data = await searchMoviesApi(stringSearch, page);
                break;
            case 'Anime':
                data = await searchMoviesApi(stringSearch, page);
                break;
        }

        setResults(data.results);
        setTotalPages(data.total_pages);
        setPage(data.page);
    }

    useEffect(() => {
        if (stringSearch) {
            fetchMovies();
        }
    }, [stringSearch, page]);

    const fetchBackPage = () => {
        setPage(prevPage => Math.max(prevPage - 1, 1));
    }

    const fetchNextPage = () => {
        setPage(prevPage => Math.min(prevPage + 1, totalPages));
    }

    const renderResults = () => {
        return (
            <FlatList
                style={{ borderTopColor: Colors.gray.c, borderTopWidth: 1 }}
                data={MOVIE_GENRE}
                keyExtractor={(item) => '#' + item.name}
                numColumns={2}
                renderItem={({ item }) => (
                    <Pressable style={Styles.FlatListButton} onPress={() => navigateByGenre(item)}>
                        <Text style={Styles.FlatListButtonText} numberOfLines={1} ellipsizeMode='tail' >{item.name}</Text>
                    </Pressable>
                )}
            />
        );
    }

    return (
        <View style={{ flex: 1, alignItems: 'center' }}>
            <View style={DS.ModalContentInput}>
                <Pressable onPress={() => goToBack()}>
                    <IconsStyle name='arrowLeft' color={Colors.sky.a} size={32} />
                </Pressable>
                <TextInput
                    style={{
                        height: '90%',
                        width: '80%',
                        fontSize: 14,
                        color: Colors.white.a,
                    }}
                    value={stringSearch}
                    onChangeText={setStringSearch}
                    placeholder="Pesquisar"
                    placeholderTextColor={Colors.white.a + 'DD'}
                    maxLength={24}
                />
                <GradientHover type='top' size={-10} />
            </View>
            {stringSearch ? (
                <>
                    <FlatlistVertical data={results} />
                    <View style={{ width: '100%', position: 'relative' }}>
                        <View style={[DS.ModalContentInput, { height: 50 }]} >
                            <Text style={{ fontSize: 20, color: Colors.gray.b }}>{`0`}</Text>
                            <Pressable
                                style={{ backgroundColor: Colors.sky.b, borderRadius: 10 }}
                                onPress={() => fetchBackPage()}
                            >
                                <IconsStyle name="arrowLeft" size={48} color={Colors.white.a} />
                            </Pressable>
                            <Text style={{ fontSize: 24, color: Colors.sky.b }}>{page}</Text>
                            <Pressable
                                style={{ backgroundColor: Colors.sky.b, borderRadius: 10 }}
                                onPress={() => fetchNextPage()}
                            >
                                <IconsStyle name="arrowRight" size={48} color={Colors.white.a} />
                            </Pressable>
                            <Text style={{ fontSize: 20, color: Colors.gray.b }}>{totalPages}</Text>
                        </View>
                        <GradientHover type='bottom' size={50} />
                    </View>
                </>
            ) : (
                <>
                    <Text style={DS.TextWhite}>
                        {`Categorias`}
                    </Text>
                    {renderResults()}
                </>
            )}
        </View>
    );
};

// Export
export default ScreenSearch;
