import React from 'react';
import { LinearGradient } from 'expo-linear-gradient';

// Recursos
import {
    Colors
} from "../../../resources/Index";

const GradientHover = ({ type, size = -10 }) => {

    switch (type) {
        case 'bottom':
            return (
                <LinearGradient
                    style={{ width: '100%', height: 10, position: 'absolute', bottom: size, zIndex: 10 }}
                    colors={['transparent', '#000000f3', Colors.black.a]} // #000000 transparent
                />
            );
        case 'top':
            return (
                <LinearGradient
                    style={{ width: '100%', height: 10, position: 'absolute', bottom: size, zIndex: 10 }}
                    colors={[Colors.black.a, '#000000f3', 'transparent']} // #000000 transparent
                />
            );
    }
};

// Export
export default GradientHover;
