import React from 'react';
import {
    View,
    ActivityIndicator,
} from 'react-native';

// Recursos
import {
    DS,
    Colors
} from "../../../resources/Index";

const ActivityTemp = () => {

    return (
        <View style={DS.containerCenter}>
            <ActivityIndicator
                color={Colors.sky.a}
                size="large"
                hidesWhenStopped={true}
            />
        </View>
    );
};

// Export
export default ActivityTemp;