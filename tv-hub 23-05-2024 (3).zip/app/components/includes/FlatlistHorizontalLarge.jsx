import React from 'react';
import {
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

// Recursos
import {
    DS,
    TMDB_PATH_IMG,
    Colors
} from "../../../resources/Index";

const FlatlistHorizontalLarge = ({ data }) => {
    const navigation = useNavigation();

    const DetailsMovie = (id) => {
        navigation.navigate('DetailsMovie', { idMovie: id });
    }

    return (
        <FlatList
            data={data || null}
            key="#"
            keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item, index }) => (
                <Pressable
                    key={index}
                    style={DS.MovieLarge}
                    onPress={() => {
                        DetailsMovie(item.id);
                    }}
                >
                    <>
                        {item.poster_path ? (
                            <Image source={{ uri: `${TMDB_PATH_IMG}/w500${item.backdrop_path}` }} style={DS.Image} />
                        ) : (
                            <Text style={[DS.TextInfo, { fontSize: 10, textAlign: 'center' }]}>{item.title || item.original_title}</Text>
                        )}
                        <LinearGradient colors={[ 'transparent', 'black']} style={{position: 'absolute', width: '100%', height: '100%', justifyContent: 'flex-end', paddingLeft: 15}}>
                            <Text numberOfLines={1} ellipsizeMode='tail' style={{ color: Colors.white.a, fontSize: 16, textAlign: 'left' }}>
                                {item ? item.title : item.original_title}
                            </Text>
                            <Text numberOfLines={1} ellipsizeMode='tail' style={{ color: Colors.white.a + 'CC', fontSize: 12, textAlign: 'left' }}>
                                {item ? item.release_date : ''}
                                {item && item.video ? ' | adulto' : ''}
                            </Text>
                        </LinearGradient>
                    </>
                </Pressable>
            )}
        />
    );
};

// Export
export default FlatlistHorizontalLarge;