import React, { useState } from 'react';
import {
    Pressable,
    View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Modals
import { 
    ModalToastMessage
} from "../../modals/Index";

// Recursos
import {
    DS,
    Colors,
    IconsStyle
} from "../../../resources/Index";

const HeaderIcon = ({ icon, text }) => {
    const [isModalToastMessage, setModalToastMessage] = useState(false);
    const navigation = useNavigation();

    const goToBack = () => {
        navigation.goBack();
    };

    return (
        <>
            <View style={[DS.ModalContentInput, { alignItems: 'center' }]}>
                <Pressable
                    style={DS.ContentButton}
                    onPress={() => goToBack()}
                >
                    <IconsStyle name="arrowLeft" size={36} color={Colors.sky.a} />
                </Pressable>
                <Pressable
                    style={[DS.TextTitle, { alignItems: 'flex-end' }]}
                    onPress={() => setModalToastMessage(!isModalToastMessage)}
                >
                    <IconsStyle name={icon} size={36} color={Colors.sky.a} />
                </Pressable>
                {/*  ==============================  */}
            </View>
            <ModalToastMessage
                isModalVisible={isModalToastMessage}
                setModalVisible={() => setModalToastMessage(!isModalToastMessage)}
                Message={text}
                CopyToast={false}
            />
        </>
    );
};

// Export
export default HeaderIcon;