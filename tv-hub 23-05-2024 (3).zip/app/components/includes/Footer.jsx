import React from 'react';
import {
    Text,
} from 'react-native';

// Recursos
import {
    Colors
} from "../../../resources/Index";

const Footer = () => {

    return (
        <Text style={{width: '100%', marginVertical: 5, color: Colors.gray.d, textAlign: 'center'}}>
            {`TV Hub v(1.0.4) Cornflower`}
        </Text>
    );
};

// Export
export default Footer;