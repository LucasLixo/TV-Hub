import React from 'react';
import {
    Modal,
    Pressable,
    Text,
    View,
} from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import Styles from './DropdownStyle';

// Recursos
import {
    DS
} from "../../../resources/Index";

const ModalDropdown = ({ isModalVisible, setModalVisible, dataArray, onSelectItem }) => {
    const handleClose = () => {
        setModalVisible();
    };

    const handleCloseOn = (itemId) => {
        setModalVisible();
        onSelectItem(itemId);
    };
    
    return (
        <Modal
            animationType='slide'
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={[DS.ModalContentShadow, { justifyContent: 'flex-end', padding: 0 }]}
                onPress={() => handleClose()}
            >
                <View style={Styles.contentDropdown}>
                    <Text style={[DS.TextWhite, Styles.titleDropdown]}>
                        {`Servidores`}
                    </Text>
                    <FlatList
                        data={dataArray || null}
                        key="#"
                        keyExtractor={(item, index) => "#" + item.id || "#" + index.toString()}
                        numColumns={1}
                        renderItem={({ item, index }) => (
                            <Pressable
                                key={index}
                                style={{
                                    width: '100%',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                }}
                                onPress={() => handleCloseOn(item.id)}
                            >
                                <Text style={Styles.textDropdown}>
                                    {item.name || ''}
                                </Text>
                            </Pressable>
                        )}
                    />
                </View>
            </Pressable>
        </Modal>
    );
};

// Export
export default ModalDropdown;