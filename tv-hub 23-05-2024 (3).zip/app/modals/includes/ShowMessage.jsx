import React from "react";
import {
    Modal,
    Pressable,
    Text,
} from "react-native";

// Recursos
import {
    DS,
    Colors,
    clipboardToast
} from "../../../resources/Index";

const ModalToastMessage = ({ isModalVisible, setModalVisible, Message, CopyToast = true }) => {
    const handleClose = () => {
        setModalVisible();
    };

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={DS.ModalContentShadow}
                onPress={() => handleClose()}
                onLongPress={() =>
                    {CopyToast && (
                        clipboardToast(Message || '')
                    )}
                }
            >
                <Text style={{ flexWrap: 'wrap', textAlign: 'center', color: Colors.white.a }}>{Message || ''}</Text>
            </Pressable>
        </Modal>
    );
};

export default ModalToastMessage;