import React, { useEffect, useState } from "react";
import { View } from "react-native";

// Recursos
import {
    encodeWithPlus,
    verifyUrl,
    VIZER_HOST,
    VIZER_SEARCH
} from "../../resources/Index";

// Components
import { 
    WebScraping
} from "../components/Index";

export const LinkMoviesToVizer = ({ search, setLinksArray }) => {
    const [extractedHref01, setExtractedHref01] = useState(null);

    const url = `${VIZER_SEARCH}${encodeWithPlus(search)}`;

    useEffect(() => {
        console.log(extractedHref01);
        if(verifyUrl(extractedHref01)){
            setLinksArray([
                {
                    id: '2',
                    name: 'Mixdrop',
                    url: `${extractUrlVizer(extractedHref01)}&sv=mixdrop`,
                },
                {
                    id: '3',
                    name: 'Filemoon',
                    url: `${extractUrlVizer(extractedHref01)}&sv=filemoon`,
                },
                {
                    id: '4',
                    name: 'Streamtape',
                    url: `${extractUrlVizer(extractedHref01)}&sv=streamtape`,
                },
            ]);
        }
    }, [extractedHref01]);

    const injectedJavaScript01 = `
    setTimeout(() => {
        const linkElement = document.querySelector("html > body > main > div#ipsLayout_contentArea > div#ipsLayout_contentWrapper > div#ipsLayout_mainArea > div.ipsBox > div.videoboxGridview > div.ipsGrid.ipsPad_half.vbGrid > div#collview > div.vbItemImage > div.caption > a[href]");
        if (linkElement) {
            window.ReactNativeWebView.postMessage(linkElement.href);
        } else {
            window.ReactNativeWebView.postMessage("Not Found");
        }
    }, 1000);
    true;
    `;

    const extractUrlVizer = (url) => {
        const regex = /(\d+)\/?$/;
        const match = url.match(regex);
        return `${VIZER_HOST}/embed/getplay.php?id=${match ? match[1] : null}`;
    }

    // const setLinksArray = (linksArray) => {
    //     console.log(linksArray);
    //     // Aqui você pode atualizar o estado ou props para refletir os links
    // };

    return (
        <View style={{ flex: 0, width: '0%', height: '0%' }}>
            <WebScraping
                isUrl={url}
                isInjectedJavaScript={injectedJavaScript01}
                setHandleMessage={(event) => setExtractedHref01(event.nativeEvent.data)}
            />
        </View>
    );
}
