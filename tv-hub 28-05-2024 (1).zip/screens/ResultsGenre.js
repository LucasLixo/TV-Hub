import React from 'react';

import HeaderTitle from '../components/HeaderTitle';
import { useRoute } from '@react-navigation/native';
import ActivityTemp from '../components/ActivityTemp';
import FlatlistVertical from '../components/FlatlistVertical';
import { View } from 'react-native';
import Styles from '../hooks/Styles';

const Search = () => {
    const route = useRoute();

    const data = route.params?.data;
    const title = route.params?.title;

    return (
        <>
            {data && title ? (
                <>
                    <HeaderTitle title={title} />
                    <View style={{ alignItems: 'center' }}>
                        <FlatlistVertical data={data} />
                    </View>
                </>
            ) : (
                <ActivityTemp />
            )}
        </>
    );
};

// Export
export default Search;