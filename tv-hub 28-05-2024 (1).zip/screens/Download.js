import React, { useState, useEffect } from 'react';
import { useRoute } from '@react-navigation/native';
import ActivityTemp from '../components/ActivityTemp';
import ActivityErro from '../components/ActivityErro';
import MyText from '../components/MyText';
import WebIframe from '../components/web/WebIframe';
import { SCRIPT_EXTRACT_FILEMOON, SCRIPT_EXTRACT_MIXDROP, SCRIPT_EXTRACT_STREAMTAPE } from '../hooks/Scripts';
import { Platform, Pressable, View } from 'react-native';
import Colors from '../hooks/Colors';
import * as FileSystem from 'expo-file-system';
import HeaderTitle from '../components/HeaderTitle';
import Styles from '../hooks/Styles';
import { clipboardToast } from '../hooks/Fuctions';
import MyTextInput from '../components/MyTextInput';

const Download = () => {
    const route = useRoute();
    const [script, setScript] = useState(null);
    const [urlVideo, setUrlVideo] = useState(null);
    const [urlExtension, setUrlExtension] = useState(null);
    const [status, setStatus] = useState(null);
    const [filenameFormat, setFilenameFormat] = useState(null);
    const [headers, setHeaders] = useState(null);

    const title = route.params?.title;
    const url = route.params?.url;
    const service = route.params?.service;

    useEffect(() => {
        switch (service) {
            case 'mixdrop':
                setScript(SCRIPT_EXTRACT_MIXDROP);
                break;
            case 'filemoon':
                setScript(SCRIPT_EXTRACT_FILEMOON);
                break;
            case 'streamtape':
                setScript(SCRIPT_EXTRACT_STREAMTAPE);
                break;
            default:
                setScript(null);
        }
    }, [service]);

    const formatUrl = (urlExtracted) => {
        if (urlExtracted.startsWith("https:")) {
            setUrlVideo(urlExtracted);
        } else if (urlExtracted.startsWith("//")) {
            setUrlVideo(`https:${urlExtracted}`);
        }
        const urlObj = new URL(urlExtracted.startsWith("//") ? `https:${urlExtracted}` : urlExtracted);
        const pathname = urlObj.pathname;
        const lastSegment = pathname.substring(pathname.lastIndexOf('/') + 1);
        const extensao = lastSegment.substring(lastSegment.lastIndexOf('.') + 1);
        setUrlExtension(extensao);
        setFilenameFormat(`${title.replace(/[^a-zA-Z0-9]+/g, '-')}.${extensao}`);
    }

    const headersUrl = async (url) => {
        try {
            const response = await fetch(url, { method: 'HEAD' });
            if (response.ok) {
                setStatus('200');
            } else {
                setStatus('Sem status do servidor');
            }
            setHeaders(response.headers);
        } catch (error) {
            console.log(error);
        }
    }

    const downloadFile = async () => {
        const result = await FileSystem.downloadAsync(
            urlVideo,
            `${FileSystem.documentDirectory}${filenameFormat}`
        );
        saveFile(result.uri, filenameFormat, result.headers["content-type"]);
    };

    const saveFile = async (uri, filename, mimetype) => {
        if (Platform.OS === "android") {
            const permissions = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
            if (permissions.granted) {
                const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
                await FileSystem.StorageAccessFramework.createFileAsync(permissions.directoryUri, filename, mimetype)
                    .then(async (uri) => {
                        await FileSystem.writeAsStringAsync(uri, base64, { encoding: FileSystem.EncodingType.Base64 });
                    })
                    .catch(e => console.log(e));
            }
        }
    };

    useEffect(() => {
        if (urlVideo) {
            headersUrl(urlVideo);
        }
    }, [urlVideo]);

    // useEffect(() => {
    //     if (urlVideo && status === '200') {
    //         // Aqui você pode adicionar qualquer lógica que dependa de urlVideo e status
    //     }
    // }, [urlVideo, status]);

    if (!script) {
        return <ActivityTemp />;
    }

    return (
        <View style={{ flex: 1, width: '100%', height: '100%' }}>
            <HeaderTitle title={`Baixar: ${title}`} />
            {(urlVideo && urlVideo !== '') ? (
                <>
                    {status === '200' ? (
                        <View style={{ flex: 1, flexDirection: 'column', padding: 10 }}>
                            <View style={Styles.Hr} />
                            <View style={Styles.CardContainer}>
                                <MyText type='topic'>{`Status`}</MyText>
                                <MyText type='description'>{status}</MyText>
                            </View>
                            <View style={Styles.Hr} />
                            <View style={Styles.CardContainer}>
                                <MyText type='topic'>{`Extensão`}</MyText>
                                <MyText type='description'>{urlExtension}</MyText>
                            </View>
                            {headers && headers.map && headers.map['content-length'] && (
                                <>
                                    <View style={Styles.Hr} />
                                    <View style={Styles.CardContainer}>
                                        <MyText type='topic'>{`Tamanho`}</MyText>
                                        <MyText type='description'>{`${Math.round(parseInt(headers.map['content-length']) / (1024 * 1024))}mb`}</MyText>
                                    </View>
                                </>
                            )}
                            <View style={Styles.Hr} />
                            <View style={Styles.CardContainer}>
                                <MyText type='topic'>{`Nome`}</MyText>
                            </View>
                            <View style={Styles.CardContainer}>
                                <MyTextInput
                                    style={{
                                        fontSize: 14,
                                        width: '100%',
                                        paddingHorizontal: 5,
                                        borderRadius: 5,
                                        backgroundColor: Colors.gray.c
                                    }}
                                    onChangeText={setFilenameFormat}
                                    value={filenameFormat}
                                />
                            </View>
                            <View style={Styles.Hr} />
                            <View style={[Styles.CardContainer, { height: 40 }]}>
                                <Pressable style={Styles.CardContainerButton} onPress={() => clipboardToast(urlVideo)}>
                                    <MyText type='topic'>{`Copiar Link`}</MyText>
                                </Pressable>
                                <Pressable style={Styles.CardContainerButton} onPress={() => downloadFile()}>
                                    <MyText type='topic'>{`Baixar`}</MyText>
                                </Pressable>
                            </View>
                        </View>
                    ) : (
                        <ActivityErro textError={status} />
                    )}
                </>
            ) : (
                <View style={{ flex: 1, alignItems: 'center' }}>
                    <View style={{ width: '100%', height: 240, position: 'relative' }}>
                        <WebIframe
                            isUrl={url}
                            isInjectedJavaScript={script}
                            setHandleMessage={(urlExtracted) => {
                                if (urlExtracted != null && urlExtracted !== 'null') {
                                    formatUrl(urlExtracted);
                                }
                            }}
                        />
                    </View>
                    <MyText type='topic' style={{ textTransform: 'uppercase' }}>{`Inicie o video para baixar`}</MyText>
                </View>
            )}
        </View>
    );
};

export default Download;
