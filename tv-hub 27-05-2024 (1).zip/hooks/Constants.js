// Vizer
export const VIZER_DOMAIN = "red";
export const VIZER_HOST = `https://vizerhd.${VIZER_DOMAIN}/`;
export const VIZER_SEARCH = `${VIZER_HOST}pesquisar/?p=`;

// Bluray
export const BLURAY_DOMAIN = "net";
export const BLURAY_HOST = `https://topfilmestorrent.${BLURAY_DOMAIN}/`;
export const BLURAY_SEARCH = `${BLURAY_HOST}?s=`;

// User Agent
export const USER_AGENT_IPHONE = "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1";
export const USER_AGENT_ANDROID = "Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36";
export const USER_AGENT_WINDOWS = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
export const USER_AGENT_MOZILLA = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0";
