import React, { useState } from 'react';
import WebScraping from '../components/web/WebScraping';
import { VIZER_HOST } from '../hooks/Constants';
import FlatlistHorizontal from '../components/FlatlistHorizontal';
import { SCRIPT_NEW_MOVIES } from '../hooks/Scripts';
import { ScrollView, View } from 'react-native';
import Styles from '../hooks/Styles';
import HeaderOptions from '../components/HeaderOptions';
import ExpandResults from '../components/ExpandResults';
import ActivityTemp from '../components/ActivityTemp';

const Movie = () => {
    const [isResultsRecents, setResultsRecents] = useState([]);
    const [isResultsAnimation, setResultsAnimation] = useState([]);
    const [isResultsAventure, setResultsAventure] = useState([]);
    const [isResultsScience, setResultsScience] = useState([]);
    const [isResultsTerror, setResultsTerror] = useState([]);

    const makeEven = (data) => {
        return data.length % 2 === 0 ? data : data.slice(0, -1);
    };
    
    return (
        <ScrollView style={Styles.ContainerView}>
            <HeaderOptions />
            <WebScraping
                isUrl={VIZER_HOST + 'assistir/filmes-online-online-2/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    setResultsRecents(makeEven(JSON.parse(results)));
                }}
            />
            <WebScraping
                isUrl={VIZER_HOST + 'genero/filmes-de-animacao-1/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    setResultsAnimation(makeEven(JSON.parse(results)));
                }}
            />
            <WebScraping
                isUrl={VIZER_HOST + 'genero/filmes-de-aventura-2/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    setResultsAventure(makeEven(JSON.parse(results)));
                }}
            />
            <WebScraping
                isUrl={VIZER_HOST + 'genero/filmes-de-ficcao-cientifica-11/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    setResultsScience(makeEven(JSON.parse(results)));
                }}
            />
            <WebScraping
                isUrl={VIZER_HOST + 'genero/filmes-de-terror-19/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    setResultsTerror(makeEven(JSON.parse(results)));
                }}
            />
            {
                isResultsRecents.length > 0 && 
                isResultsAnimation.length > 0 && 
                isResultsAventure.length > 0 &&
                isResultsScience.length > 0 &&
                isResultsTerror.length > 0 ?
            (
                <>
                    <ExpandResults title='Adicionados' data={isResultsRecents} />
                    <FlatlistHorizontal data={isResultsRecents.slice(0, isResultsRecents.length / 2)} />
                    <ExpandResults title='Animação' data={isResultsAnimation} />
                    <FlatlistHorizontal data={isResultsAnimation.slice(0, isResultsAnimation.length / 2)} />
                    <ExpandResults title='Aventura' data={isResultsAventure} />
                    <FlatlistHorizontal data={isResultsAventure.slice(0, isResultsAventure.length / 2)} />
                    <ExpandResults title='Ficção Científica' data={isResultsScience} />
                    <FlatlistHorizontal data={isResultsScience.slice(0, isResultsScience.length / 2)} />
                    <ExpandResults title='Terror' data={isResultsTerror} />
                    <FlatlistHorizontal data={isResultsTerror.slice(0, isResultsTerror.length / 2)} />
                </>
            ) : (
                <View style={{ width: '100%', height: '100%' }}>
                    <ActivityTemp />
                </View>
            )}
        </ScrollView>
    );
};

// Export
export default Movie;
