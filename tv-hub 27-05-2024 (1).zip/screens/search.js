import React, { useEffect, useState } from 'react';
import WebScraping from '../components/web/WebScraping';
import HeaderSearch from '../components/HeaderSearch';
import { View } from 'react-native';
import { encodeWithPlus } from '../hooks/Fuctions';
import { VIZER_SEARCH } from '../hooks/Constants';
import ActivityTemp from '../components/ActivityTemp';
import { SCRIPT_NEW_MOVIES } from '../hooks/Scripts';
import Styles from '../hooks/Styles';
import FlatlistVertical from '../components/FlatlistVertical';

const Search = ({ type }) => {
    const [isString, setString] = useState('');
    const [isResults, setResults] = useState('');
    const [isStringSearch, setStringSearch] = useState('');

    useEffect(() => {
        setStringSearch(encodeWithPlus(isString));
    }, [isString]);

    return (
        <View style={Styles.ContainerView}>
            <HeaderSearch setStringSearch={setString} />
            {isStringSearch && (
                <WebScraping
                    isUrl={VIZER_SEARCH + isStringSearch}
                    isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                    setHandleMessage={(results) => {
                        setResults(JSON.parse(results));
                    }}
                />
            )}
            {isResults.length > 0 ? (
                <FlatlistVertical data={isResults} />
            ) : (
                <View style={{ width: '100%', height: '100%' }}>
                    <ActivityTemp />
                </View>
            )}
        </View>
    );
};

// Export
export default Search;