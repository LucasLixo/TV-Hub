import React, { useState } from 'react';

import HeaderTitle from '../../components/HeaderTitle';
import { Image, Pressable, ScrollView, View } from 'react-native';
import MyText from '../../components/MyText';
import { useNavigation, useRoute } from '@react-navigation/native';
import Styles from '../../hooks/Styles';
import WebScraping from '../../components/web/WebScraping';
import { SCRIPT_DETAILS_MOVIES } from '../../hooks/Scripts';
import ActivityTemp from '../../components/ActivityTemp';
import ShowModal from '../../components/ShowModal'
import ShowModalBottom from '../../components/ShowModalBottom'
import Colors from '../../hooks/Colors';
import IconsStyle from '../../hooks/IconsStyle';
import WebIframe from '../../components/web/WebIframe';
import { clipboardToast, extractUrlVizer } from '../../hooks/Fuctions';

const DetailsMovie = () => {
    const route = useRoute();
    const [isDetails, setDetails] = useState(null);
    const [isShowMessage, setShowMessage] = useState(false);
    const [isShowImage, setShowImage] = useState(false);

    const [isShowComments, setShowComments] = useState(false);
    const [isShowPlayer, setShowPlayer] = useState(false);
    const [isShowDownload, setShowDownload] = useState(false);

    const data = route.params?.data;
    const navigation = useNavigation();

    return (
        <>
            {data && (
                <ScrollView style={{ width: '100%', paddingLeft: 10 }}>
                    <HeaderTitle title={data.title} />
                    {isDetails ? (
                        <>
                            <View style={{ alignItems: 'center' }}>
                                <Pressable onPress={() => setShowImage(!isShowImage)}>
                                    <Image
                                        style={Styles.FlatlistHorizontal}
                                        source={{ uri: data.img }}
                                    />
                                    {data.language == 'DUB' ? (
                                        <MyText
                                            style={[Styles.FlatlistHorizontalLanguage, { fontSize: 16, fontWeight: 'bold' }]}
                                            type='subtitle'
                                        >
                                            {`Dublado`}
                                        </MyText>
                                    ) : (
                                        <MyText
                                            style={[Styles.FlatlistHorizontalLanguage, { fontSize: 16, fontWeight: 'bold' }]}
                                            type='subtitle'
                                        >
                                            {`Legendado`}
                                        </MyText>
                                    )}
                                </Pressable>
                            </View>
                            <View style={Styles.Hr} />
                            <View style={Styles.ContainerServices}>
                                <Pressable
                                    style={Styles.ContainerServicesPressable}
                                    onPress={() => setShowComments(!isShowComments)}
                                >
                                    <IconsStyle name='chat' color={Colors.text.a} size={32} />
                                </Pressable>
                                <Pressable
                                    style={Styles.ContainerServicesPressable}
                                    onPress={() => setShowPlayer(!isShowPlayer)}
                                >
                                    <IconsStyle name='play' color={Colors.text.a} size={32} />
                                </Pressable>
                                <Pressable
                                    style={Styles.ContainerServicesPressable}
                                    onPress={() => setShowDownload(!isShowDownload)}
                                >
                                    <IconsStyle name='download' color={Colors.text.a} size={32} />
                                </Pressable>
                            </View>
                            {isDetails.title && (
                                <>
                                    <View style={Styles.Hr} />
                                    <MyText type='topic'>
                                        {'Titulo original: '}
                                        <MyText type='description'>
                                            {isDetails.title}
                                        </MyText>
                                    </MyText>
                                </>
                            )}
                            <Pressable
                                onPress={() => setShowMessage(!isShowMessage)}
                                style={{ flexDirection: 'column' }}
                            >
                                <View style={Styles.Hr} />
                                <MyText
                                    type='topic'
                                    numberOfLines={5}
                                    ellipsizeMode='tail'
                                >
                                    {`Sinopse: `}
                                    <MyText type='description'>
                                        {isDetails.sinopse.replace('Ler mais...', '')}
                                    </MyText>
                                </MyText>
                            </Pressable>
                            <View style={Styles.Hr} />
                            <MyText type='topic'>
                                {`Duração: `}
                                <MyText type='description'>
                                    {data.time}
                                </MyText>
                            </MyText>
                            <View style={Styles.Hr} />
                            <MyText type='topic'>
                                {`Diretor: `}
                                <MyText type='description'>
                                    {isDetails.diretor.replace(/<b>.*?<\/b> /g, '')}
                                </MyText>
                            </MyText>
                            <View style={Styles.Hr} />
                            <MyText type='topic'>
                                {`Elenco: `}
                                <MyText type='description'>
                                    {isDetails.elenco.replace(/<b>.*?<\/b> /g, '')}
                                </MyText>
                            </MyText>
                            <View style={Styles.Hr} />
                            <MyText type='topic'>
                                {`Produtor: `}
                                <MyText type='description'>
                                    {isDetails.produtor.replace(/<b>.*?<\/b> /g, '')}
                                </MyText>
                            </MyText>
                            <View style={Styles.Hr} />
                            <ShowModal
                                isModalVisible={isShowMessage}
                                setModalVisible={() => setShowMessage(!isShowMessage)}
                                Data={`Sinopse: ${isDetails.sinopse.replace('Ler mais...', '')}`}
                            />
                            <ShowModal
                                isModalVisible={isShowImage}
                                setModalVisible={() => setShowImage(!isShowImage)}
                                Data={data.img}
                            />
                            <ShowModalBottom
                                isModalVisible={isShowComments}
                                setModalVisible={() => setShowComments(!isShowComments)}
                                title='Comentários'
                            >
                                <WebIframe
                                    isUrl={isDetails.comments}
                                />
                            </ShowModalBottom>
                            <ShowModalBottom
                                isModalVisible={isShowPlayer}
                                setModalVisible={() => setShowPlayer(!isShowPlayer)}
                                title='Players'
                                height={40}
                            >
                                <Pressable
                                    onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=mixdrop`)}
                                    onPress={() => {
                                        setShowPlayer(!isShowPlayer);
                                        navigation.navigate('PlayerVideo', {
                                            url: `${extractUrlVizer(data.url)}&sv=mixdrop`,
                                            service: 'mixdrop'
                                        })
                                    }}
                                >
                                    <MyText type='title' style={{ color: Colors.text.a }}>{`Mixdrop`}</MyText>
                                </Pressable>
                                <View style={Styles.Hr} />
                                <Pressable
                                    onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=filemoon`)}
                                    onPress={() => {
                                        setShowPlayer(!isShowPlayer);
                                        navigation.navigate('PlayerVideo', {
                                            url: `${extractUrlVizer(data.url)}&sv=filemoon`,
                                            service: 'filemoon'
                                        })
                                    }}
                                >
                                    <MyText type='title' style={{ color: Colors.text.a }}>{`Filemoon`}</MyText>
                                </Pressable>
                                <View style={Styles.Hr} />
                                <Pressable
                                    onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=streamtape`)}
                                    onPress={() => {
                                        setShowPlayer(!isShowPlayer);
                                        navigation.navigate('PlayerVideo', {
                                            url: `${extractUrlVizer(data.url)}&sv=streamtape`,
                                            service: 'streamtape'
                                        })
                                    }}
                                >
                                    <MyText type='title' style={{ color: Colors.text.a }}>{`Streamtape`}</MyText>
                                </Pressable>
                            </ShowModalBottom>
                            <ShowModalBottom
                                isModalVisible={isShowDownload}
                                setModalVisible={() => setShowDownload(!isShowDownload)}
                                title='Baixar'
                            >
                                <MyText type='title'>
                                    {`Em breve`}
                                </MyText>
                            </ShowModalBottom>
                        </>
                    ) : (
                        <View style={{ width: '100%', height: '100%' }}>
                            <ActivityTemp />
                        </View>
                    )}
                    <WebScraping
                        isUrl={data.url}
                        isInjectedJavaScript={SCRIPT_DETAILS_MOVIES}
                        setHandleMessage={(results) => setDetails(JSON.parse(results))}
                    />
                </ScrollView>
            )}
        </>
    );
};

// Export
export default DetailsMovie;