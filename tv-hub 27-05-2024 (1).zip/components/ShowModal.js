import React from "react";
import {
    Image,
    Linking,
    Modal,
    Pressable,
    Text,
} from "react-native";
import Styles from "../hooks/Styles";
import Colors from "../hooks/Colors";
import { clipboardToast } from "../hooks/Fuctions";

const ShowModal = ({ isModalVisible, setModalVisible, Data, CopyToast = false }) => {
    const handleClose = () => {
        setModalVisible();
    };

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={Styles.ModalContentShadow}
                onPress={() => handleClose()}
                onLongPress={() => {
                    CopyToast && (
                        clipboardToast(Data || '')
                    )
                }
                }
            >
                {Data.startsWith("https://") ? (
                    <Pressable onPress={() => Linking.openURL(Data)}>
                        <Image
                            source={{ uri: Data }}
                            style={{ width: 220, height: 330, borderRadius: 10 }}
                            resizeMode='cover'
                        />
                    </Pressable>
                ) : (
                    <Text style={{ flexWrap: 'wrap', textAlign: 'center', color: Colors.text.a }}>{Data || ''}</Text>
                )}
            </Pressable>
        </Modal>
    );
};

export default ShowModal;