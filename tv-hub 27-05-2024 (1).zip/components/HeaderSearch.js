import React from 'react';
import {
    View,
    TextInput,
    Pressable,
} from 'react-native';

import Colors from '../hooks/Colors';
import Styles from '../hooks/Styles';
import IconsStyle from '../hooks/IconsStyle';
import { useNavigation } from '@react-navigation/native';

const HeaderOptions = ({ setStringSearch }) => {
    const navigation = useNavigation();

    return (
        <>
            <View style={Styles.Header}>
                <Pressable onPress={() => navigation.goBack()}>
                    <IconsStyle name='arrowLeft' size={32} color={Colors.sky.a} stroke={Colors.sky.a} strokeWidth={2} />
                </Pressable>
                <TextInput
                    style={{ width: '90%', height: '100%', fontSize: 18, color: Colors.text.a }}
                    placeholder='Pesquisar'
                    placeholderTextColor={Colors.text.b}
                    onChangeText={setStringSearch}
                    maxLength={24}
                />
            </View>
            <View style={Styles.Hr} />
        </>
    );
};

// Export
export default HeaderOptions;