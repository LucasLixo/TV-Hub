import React, { useRef } from "react";
import {
    Modal,
    Pressable,
    View,
    PanResponder,
} from "react-native";
import Colors from "../hooks/Colors";
import MyText from "./MyText";
import { LinearGradient } from "expo-linear-gradient";

const ShowModalBottom = ({ isModalVisible, setModalVisible, title, children }) => {
    const handleClose = () => {
        setModalVisible(false);
    };

    const panResponder = useRef(
        PanResponder.create({
            onMoveShouldSetPanResponder: (evt, gestureState) => {
                return gestureState.dy > 0;
            },
            // onPanResponderMove: (evt, gestureState) => {
            // },
            onPanResponderRelease: (evt, gestureState) => {
                if (gestureState.dy > 50) {
                    handleClose();
                }
            },
        })
    ).current;
    
    return (
        <Modal
            animationType="slide"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <View style={{ flex: 1 }}>
                <Pressable
                    style={{
                        backgroundColor: Colors.background.c,
                        width: '100%',
                        height: '14%',
                        position: 'relative',
                        flexDirection: 'column',
                        justifyContent: 'flex-end',
                    }}
                    onPress={() => handleClose()}
                    {...panResponder.panHandlers}
                />
                <MyText
                    type="title"
                    style={{
                        width: '100%',
                        height: '6%',
                        backgroundColor: Colors.sky.b,
                        color: Colors.text.a,
                        textAlignVertical: 'center',
                        textAlign: 'center',
                        borderTopRightRadius: 15,
                        borderTopLeftRadius: 15,
                    }}
                    {...panResponder.panHandlers}
                >
                    {title}
                </MyText>
                <View style={{
                    width: '100%',
                    height: '80%',
                    position: 'relative',
                    padding: 10,
                    backgroundColor: Colors.background.a
                }}>
                    <LinearGradient
                        colors={[Colors.background.a, Colors.background.a, 'transparent']}
                        style={{ 
                            width: '110%', 
                            height: 20, 
                            position: 'absolute', 
                            zIndex: 10,
                        }}
                    />
                    {children}
                </View>
            </View>
        </Modal>
    );
};

export default ShowModalBottom;
