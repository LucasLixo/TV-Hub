import { StyleSheet } from 'react-native';

// Recursos
import { Colors } from "../../../resources/Index";

const Styles = StyleSheet.create({
    FlatListButton: {
        width: 160,
        margin: 10,
        height: 50,
        borderRadius: 10,
        backgroundColor: Colors.sky.b,
        alignItems: 'center',
        justifyContent: 'center'
    },
    FlatListButtonText: {
        color: Colors.white.a,
        fontSize: 18,
        fontWeight: 'bold',
    },
});

// Export
export default Styles;