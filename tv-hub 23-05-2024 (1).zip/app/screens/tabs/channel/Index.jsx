import React from 'react';
import {
    View,
    Text,
} from 'react-native';

// Recursos
import {
    DS,
} from "../../../../resources/Index";

// Components
import {
    HeaderTop,
    Footer
} from "../../../components/Index";

const channel = () => {

    return (
        <>
            <HeaderTop type='channel' />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Canais`}</Text>
                <Footer />
            </View>
        </>
    );
};

// Export
export default channel;