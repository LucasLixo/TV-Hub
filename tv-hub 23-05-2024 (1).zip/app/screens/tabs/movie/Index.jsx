import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Pressable,
    ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Api
import {
    getNewsMoviesApi,
    getGenreMoviesApi,
} from '../../../api/TMDB';

// Recursos
import {
    DS,
    IconsStyle,
    Colors,
    MOVIE_GENRE,
} from "../../../../resources/Index";

// Components
import {
    FlatlistHorizontal,
    FlatlistHorizontalLarge,
    ActivityTemp,
    Footer,
    HeaderTop,
} from "../../../components/Index";

const Movie = () => {
    const [NewsMovies, setNewsMovies] = useState(null);
    const [GenreMovies, setGenreMovies] = useState([]);
    const IndexGenreMovies = [2, 4, 5, 6, 11];
    const navigation = useNavigation();

    useEffect(() => {
        const fetchNewsMovies = async () => {
            const data = await getNewsMoviesApi();
            setNewsMovies(data.results);
        };

        fetchNewsMovies();
    }, []);

    useEffect(() => {
        const fetchGenreMovies = async () => {
            const genreMoviesData = await Promise.all(
                IndexGenreMovies.map(async (index) => {
                    const data = await getGenreMoviesApi(MOVIE_GENRE[index].id);
                    return { id: MOVIE_GENRE[index].id, name: MOVIE_GENRE[index].name, movies: data };
                })
            );
            setGenreMovies(genreMoviesData);
        };

        fetchGenreMovies();
    }, []);

    const navigateByGenre = (genre) => {
        navigation.navigate('SearchGenre', {
            dataGenre: {
                Type: 'Movie',
                Id: genre.id,
                Name: genre.name,
            }
        });
    };

    return (
        <>
            <HeaderTop type="Movie" />
            {NewsMovies ? (
                <ScrollView style={DS.containerB}>
                    {/*  ==============================  */}
                    <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Text style={DS.TextWhite}>
                            {`Lançamentos`}
                        </Text>
                        <Pressable onPress={() => console.log("teste")}>
                            <IconsStyle name="arrowRight" size={32} color={Colors.white.a} />
                        </Pressable>
                    </View>
                    <FlatlistHorizontalLarge data={NewsMovies} />
                    {/*  ==============================  */}
                    {GenreMovies.map((genre, index) => (
                        <React.Fragment key={index}>
                            <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                <Text style={DS.TextWhite}>
                                    {genre.name}
                                </Text>
                                <Pressable onPress={() => navigateByGenre(genre)}>
                                    <IconsStyle name="arrowRight" size={32} color={Colors.white.a} />
                                </Pressable>
                            </View>
                            <FlatlistHorizontal data={genre.movies.results} />
                        </React.Fragment>
                    ))}
                    <Footer />
                </ScrollView>
            ) : (
                <ActivityTemp />
            )}
        </>
    );
};

// Export
export default Movie;
