import React from 'react';
import {
    View,
} from 'react-native';
import WebView from 'react-native-webview';

// Recursos
import {
    DS,
    Colors,
    USER_AGENT_MOZILLA
} from "../../../resources/Index";

// Componentes
import { 
    HeaderTitle 
} from '../../components/Index';

const Config = () => {
    const configHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
            <style type="text/css">
                html, body, body * {
                    padding: 0,
                    margin: 0,
                    boxsizing: border-box;
                    color: ${Colors.white.a};
                }
                html, body {
                    padding: 20px 0,
                }
                body {
                    background: ${Colors.black.a};
                }
            </style>
        </head>
        <body>
            <ul>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
            </ul>
        </body>
        </html>
    `;

    return (
        <>
            <HeaderTitle title="Configurações" />
            <View style={DS.containerB}>
                <WebView
                    style={{ flex: 1, backgroundColor: Colors.black.a }}
                    source={{ html: configHtml }}
                    userAgent={USER_AGENT_MOZILLA}
                />
            </View>
        </>
    );
};

// Export
export default Config;