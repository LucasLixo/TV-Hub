import React from 'react';
import {
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Recursos
import {
    DS,
    TMDB_PATH_IMG,
    Colors
} from "../../../resources/Index";

const FlatlistHorizontal = ({ data }) => {
    const navigation = useNavigation();

    const DetailsMovie = (id) => {
        navigation.navigate('DetailsMovie', { idMovie: id });
    }

    return (
        <FlatList
            data={data || null}
            key="#"
            keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item, index }) => (
                <Pressable
                    key={index}
                    style={DS.Movie}
                    onPress={() => {
                        DetailsMovie(item.id);
                    }}
                >
                    <>
                        {item.adult && (
                            <Text style={{
                                position: 'absolute',
                                fontSize: 8,
                                left: 5,
                                bottom: 5,
                                color: Colors.white.a,
                                backgroundColor: Colors.sky.b,
                                padding: 3,
                                borderRadius: 5,
                                zIndex: 10,
                            }}>
                                {`Adulto`}
                            </Text>
                        )}
                        {item.poster_path ? (
                            <Image source={{ uri: `${TMDB_PATH_IMG}/w342${item.poster_path}` }} style={DS.Image} />
                        ) : (
                            <Text style={[DS.TextInfo, { fontSize: 10, textAlign: 'center' }]}>{item.title || item.original_title}</Text>
                        )}
                    </>
                </Pressable>
            )}
        />
    );
};

// Export
export default FlatlistHorizontal;