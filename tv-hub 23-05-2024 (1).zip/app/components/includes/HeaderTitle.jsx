import React from 'react';
import {
    Pressable,
    View,
    Text,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Components
import GradientHover from './GradientHover';

// Recursos
import {
    DS,
    Colors,
    IconsStyle
} from "../../../resources/Index";

const HeaderTitle = ({ title }) => {
    const navigation = useNavigation();

    const goToBack = () => {
        navigation.goBack();
    };

    return (
        <View style={[DS.ModalContentInput, { alignItems: 'center' }]}>
            <Pressable
                style={DS.ContentButton}
                onPress={() => goToBack()}
            >
                <IconsStyle name="arrowLeft" size={36} color={Colors.sky.a} />
            </Pressable>
            <Text
                numberOfLines={1}
                ellipsizeMode="tail"
                style={DS.TextTitle}
            >
                {title || ''}
            </Text>
            <GradientHover type='top' size={-10} />
        </View>
    );
};

// Export
export default HeaderTitle;