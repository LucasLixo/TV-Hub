import { useEffect } from 'react';
import {
    ToastAndroid,
} from "react-native";
import * as ScreenOrientation from 'expo-screen-orientation';
import * as Clipboard from 'expo-clipboard';

export const clipboardToast = async (Clip) => {
    await Clipboard.setStringAsync(Clip);
    ToastAndroid.show(`Copiado!`, ToastAndroid.SHORT);
}

export const clipboardImageToast = async (Clip) => {
    // Base64
    await Clipboard.setImageAsync(Clip);
    ToastAndroid.show(`Copiado!`, ToastAndroid.SHORT);
}

export const encodeWithPlus = (str) => {
    return encodeURIComponent(str).replace(/%20/g, '+');
}

export const verifyUrl = (url) => {
    return url !== 'Not Found' && url !== null;
};

export const OrientationAllow = () => {
    useEffect(() => {
        ScreenOrientation.lockAsync(
            ScreenOrientation.OrientationLock.LANDSCAPE_LEFT |
            ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT
        );
        return () => {
            ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        };
    }, []);
};