import React, { useRef } from 'react';
import WebView from 'react-native-webview';
import { USER_AGENT_IPHONE } from '../../hooks/Constants';
import Styles from '../../hooks/Styles';

const WebIframe = ({ isUrl, isInjectedJavaScript, setHandleErro }) => {
    const WebRef = useRef(null);

    const onShouldStartLoadWithRequest = (request) => {
        return false;
    };

    return (
        <WebView
            ref={WebRef}
            source={{ uri: isUrl }}
            style={Styles.WebView}
            // javaScript Enabled
            javaScriptEnabled={true}
            // javaScript Can Open Window
            javaScriptCanOpenWindowsAutomatically={false}
            setSupportMultipleWindows={false}
            // dom Storage Enabled
            domStorageEnabled={true}
            // scales Page To Fit
            scalesPageToFit={false}
            // on Error
            onError={(syntheticEvent) => {
                const { nativeEvent } = syntheticEvent;
                setHandleErro(nativeEvent.description);
            }}
            onShouldStartLoadWithRequest={onShouldStartLoadWithRequest}
            injectedJavaScript={isInjectedJavaScript}
            // start In Loading State
            startInLoadingState={false}
            // userAgent
            userAgent={USER_AGENT_IPHONE}
            // allows Protected Media
            allowsProtectedMedia={true}
            allowsFullscreenVideo={true}
            // text size android
            textZoom={100}
            // Downloads
            cacheEnabled={true}
            cacheMode='LOAD_DEFAULT'
            saveFormDataDisabled={false}
            allowFileAccess={false}
            // Icognito
            incognito={false}
            // Scrool
            overScrollMode='always'
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            // enable zoom
            setBuiltInZoomControls={false}
            // load media - always
            mixedContentMode='compatibility'
        />
    );
};

// Export
export default WebIframe;
