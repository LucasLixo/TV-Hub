import React, { useState, useEffect } from 'react';
import WebScraping from '../components/web/WebScraping';
import { VIZER_HOST } from '../hooks/Constants';
import FlatlistHorizontal from '../components/FlatlistHorizontal';
import { SCRIPT_NEW_MOVIES } from '../hooks/Scripts';
import { ScrollView, View, FlatList } from 'react-native';
import Styles from '../hooks/Styles';
import HeaderOptions from '../components/HeaderOptions';
import ExpandResults from '../components/ExpandResults';
import ActivityTemp from '../components/ActivityTemp';

const genres = [
  { key: 'recents', url: 'assistir/filmes-online-online-2/', title: 'Adicionados' },
  { key: 'animation', url: 'genero/filmes-de-animacao-1/', title: 'Animação' },
  { key: 'adventure', url: 'genero/filmes-de-aventura-2/', title: 'Aventura' },
  { key: 'science', url: 'genero/filmes-de-ficcao-cientifica-11/', title: 'Ficção Científica' },
  { key: 'terror', url: 'genero/filmes-de-terror-19/', title: 'Terror' },
];

const Movie = () => {
  const [results, setResults] = useState({
    recents: [],
    animation: [],
    adventure: [],
    science: [],
    terror: [],
  });

  const makeEven = (data) => (data.length % 2 === 0 ? data : data.slice(0, -1));

  const handleMessage = (key, data) => {
    setResults((prevResults) => ({
      ...prevResults,
      [key]: makeEven(JSON.parse(data)),
    }));
  };

  const allDataLoaded = Object.values(results).every((data) => data.length > 0);

  return (
    <>
      {genres.map(({ key, url }) => (
        <WebScraping
          key={key}
          isUrl={`${VIZER_HOST}${url}`}
          isInjectedJavaScript={SCRIPT_NEW_MOVIES}
          setHandleMessage={(data) => handleMessage(key, data)}
        />
      ))}
      {allDataLoaded ? (
        <ScrollView style={Styles.ContainerView}>
          <HeaderOptions />
          {genres.map(({ key, title }) => (
            <View key={key}>
              <ExpandResults title={title} data={results[key]} />
              <FlatlistHorizontal data={results[key].slice(0, results[key].length / 2)} />
            </View>
          ))}
        </ScrollView>
      ) : (
        <View style={{ flex: 1, width: '100%', height: '100%', position: 'absolute' }}>
          <HeaderOptions />
          <ActivityTemp />
        </View>
      )}
    </>
  );
};

export default Movie;
