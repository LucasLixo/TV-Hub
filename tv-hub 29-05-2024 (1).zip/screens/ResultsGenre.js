import React from 'react';

import HeaderTitle from '../components/HeaderTitle';
import { useRoute } from '@react-navigation/native';
import ActivityTemp from '../components/ActivityTemp';
import FlatlistVertical from '../components/FlatlistVertical';
import { ScrollView } from 'react-native';
import Styles from '../hooks/Styles';

const Search = () => {
    const route = useRoute();

    const data = route.params?.data;
    const title = route.params?.title;

    return (
        <>
            {data && title ? (
                <ScrollView style={[Styles.ContainerView, { paddingRight: 10 }]}>
                    <HeaderTitle title={title} />
                    <FlatlistVertical data={data} />
                </ScrollView>
            ) : (
                <ActivityTemp />
            )}
        </>
    );
};

// Export
export default Search;