export const SCRIPT_NEW_MOVIES = `
setTimeout(() => {
  const cards = document.querySelectorAll('ol > div > div.ipsGrid > div#collview');
  const extractedData = Array.from(cards).map(card => {
      const languageElement = card.querySelector('div.vbItemImage > div.TopLeft > span.capa-info.capa-audio');
      const titleElement = card.querySelector('div.vbItemImage > div.caption > a[title]');
      const urlElement = card.querySelector('div.vbItemImage > div.caption > a[href]');
      const dateElement = card.querySelector('div.vbItemImage > div.caption > span.y');
      const timeElement = card.querySelector('div.vbItemImage > div.caption > span.t');
      const imgElement = card.querySelector('div.vbItemImage > a > div[data-background-src]');

      const language = languageElement.textContent.trim();
      const title = titleElement.textContent.trim();
      const date = dateElement.textContent.trim();
      const time = timeElement.textContent.trim();
      const url = urlElement.getAttribute('href').trim();
      const img = imgElement.getAttribute('data-background-src').trim();

      return { language, title, date, time, url, img };
  });
  window.ReactNativeWebView.postMessage(JSON.stringify(extractedData));
}, 1000);
true;
`;

export const SCRIPT_DETAILS_MOVIES = `
setTimeout(() => {
  const card = document.querySelector('main#ipsLayout_body');

  if (card) {
      const titleElement = card.querySelector('h1 > span.titulo > small');
      const sinopseElement = card.querySelector('div.esquerda > div.sinopse');
      const spans = card.querySelectorAll('div.extrainfo > span');

      const title = titleElement ? titleElement.textContent.trim() : '';
      const sinopse = sinopseElement ? sinopseElement.textContent.trim() : '';
      const diretor = spans[0] ? spans[0].innerHTML.trim() : '';
      const elenco = spans[1] ? spans[1].innerHTML.trim() : '';
      const produtor = spans[2] ? spans[2].innerHTML.trim() : '';

      window.ReactNativeWebView.postMessage(JSON.stringify({
          title: title,
          sinopse: sinopse,
          diretor: diretor,
          elenco: elenco,
          produtor: produtor,
      }));
  }
}, 1000);
true;
`;

export const SCRIPT_GET_REQUESTS = `
setTimeout(() => {
  var open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function () {
      this.addEventListener("load", function () {
          var message = { "status": this.status, "response": this.response }
          window.ReactNativeWebView.postMessage(JSON.stringify(message));
      });
      open.apply(this, arguments);
  };
}, 1000);
true;
`;