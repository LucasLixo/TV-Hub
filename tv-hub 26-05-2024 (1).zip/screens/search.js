import React from 'react';

import HeaderSearch from '../components/HeaderSearch';
import { View } from 'react-native';
import MyText from '../components/MyText';

const Search = ({ type }) => {

    return (
        <>
            <HeaderSearch />
        </>
    );
};

// Export
export default Search;