import React, { useEffect } from 'react';

import ActivityTemp from '../components/ActivityTemp';
import { useRoute } from '@react-navigation/native';
// import * as ScreenOrientation from 'expo-screen-orientation';
import WebScraping from '../components/web/WebScraping';
import { SCRIPT_GET_REQUESTS, SCRIPT_GET_VIDEOS } from '../hooks/Scripts';

const PlayerVideo = () => {
    const route = useRoute();

    const url = route.params?.url;

    /* useEffect(() => {
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT);
        return () => {
            ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        };
    }); */

    return (
        <>
            {url ? (
                <WebScraping
                    isUrl={url}
                    isInjectedJavaScript={SCRIPT_GET_REQUESTS}
                    setHandleMessage={(results) => console.log(results)}
                />
            ) : (
                <ActivityTemp />
            )}
        </>
    );
};

// Export
export default PlayerVideo;

                {/* <WebPlayer
                    isUrl={url}
                    setHandleErro={(erro) => console.log(erro)}
                /> */}