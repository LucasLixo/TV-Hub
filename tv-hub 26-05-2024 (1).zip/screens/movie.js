import React, { useState } from 'react';
import WebScraping from '../components/web/WebScraping';
import { VIZER_HOST } from '../hooks/Constants';
import FlatlistHorizontal from '../components/FlatlistHorizontal';
import { SCRIPT_NEW_MOVIES } from '../hooks/Scripts';
import { ScrollView, View } from 'react-native';
import Styles from '../hooks/Styles';
import HeaderOptions from '../components/HeaderOptions';
import ExpandResults from '../components/ExpandResults';
import ActivityTemp from '../components/ActivityTemp';

const Movie = () => {
    const [isResultsRecents, setResultsRecents] = useState([]);
    const [isResultsAnimation, setResultsAnimation] = useState([]);

    const makeEven = (data) => {
        return data.length % 2 === 0 ? data : data.slice(0, -1);
    };

    return (
        <View style={{ width: '100%', height: '100%' }}>
            <WebScraping
                isUrl={VIZER_HOST + 'assistir/filmes-online-online-2/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    // console.log(VIZER_HOST + 'assistir/filmes-online-online-2/');
                    setResultsRecents(makeEven(JSON.parse(results)));
                }}
            />
            <WebScraping
                isUrl={VIZER_HOST + 'genero/filmes-de-animacao-1/'}
                isInjectedJavaScript={SCRIPT_NEW_MOVIES}
                setHandleMessage={(results) => {
                    // console.log(VIZER_HOST + 'genero/filmes-de-animacao-1/');
                    setResultsAnimation(makeEven(JSON.parse(results)));
                }}
            />
            {isResultsRecents.length > 0 && isResultsAnimation.length > 0 ? (
                <ScrollView style={Styles.ContainerView}>
                    <HeaderOptions />
                    <ExpandResults title='Recentes' data={isResultsRecents} />
                    <FlatlistHorizontal data={isResultsRecents.slice(0, isResultsRecents.length / 2)} />
                    <ExpandResults title='Animação' data={isResultsAnimation} />
                    <FlatlistHorizontal data={isResultsAnimation.slice(0, isResultsAnimation.length / 2)} />
                </ScrollView>
            ) : (
                <ActivityTemp />
            )}
        </View>
    );
};

// Export
export default Movie;
