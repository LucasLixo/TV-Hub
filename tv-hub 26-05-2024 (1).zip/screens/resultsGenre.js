import React from 'react';

import HeaderTitle from '../components/HeaderTitle';
import { useRoute } from '@react-navigation/native';
import ActivityTemp from '../components/ActivityTemp';
import FlatlistVertical from '../components/FlatlistVertical';
import { View } from 'react-native';

const Search = () => {
    const route = useRoute();

    const data = route.params?.data;

    return (
        <>
            {data ? (
                <>
                    <HeaderTitle title={data.title} />
                    <View style={{ alignItems: 'center' }}>
                        <FlatlistVertical data={data.data} />
                    </View>
                </>
            ) : (
                <ActivityTemp />
            )}
        </>
    );
};

// Export
export default Search;