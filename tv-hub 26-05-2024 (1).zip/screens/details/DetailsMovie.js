import React, { useState } from 'react';

import HeaderTitle from '../../components/HeaderTitle';
import { Image, Pressable, ScrollView, View } from 'react-native';
import MyText from '../../components/MyText';
import { useNavigation, useRoute } from '@react-navigation/native';
import Styles from '../../hooks/Styles';
import WebScraping from '../../components/web/WebScraping';
import { SCRIPT_DETAILS_MOVIES } from '../../hooks/Scripts';
import { clipboardToast, extractUrlVizer } from '../../hooks/Fuctions';
import ActivityTemp from '../../components/ActivityTemp';
import ShowMessage from '../../components/ShowMessage'
import Colors from '../../hooks/Colors';

const DetailsMovie = () => {
    const route = useRoute();
    const [isDetails, setDetails] = useState(null);
    const [isShowMessage, setShowMessage] = useState(false);

    const data = route.params?.data;
    const navigation = useNavigation();

    return (
        <>
            {data && (
                <ScrollView>
                    {isDetails ? (
                        <>
                            <HeaderTitle title={data.title} />
                            <View style={{ paddingLeft: 10 }}>
                                <View style={Styles.DetailsTop}>
                                    <View style={{ width: '50%' }}>
                                        <Image
                                            style={Styles.FlatlistHorizontal}
                                            source={{ uri: data.img }}
                                        />
                                        {data.language == 'DUB' ? (
                                            <MyText text='Dublado' type='subtitle' style={Styles.FlatlistHorizontalLanguage} />
                                        ) : (
                                            <MyText text='Legendado' type='subtitle' style={Styles.FlatlistHorizontalLanguage} />
                                        )}
                                    </View>
                                    <Pressable
                                        onPress={() => setShowMessage(!isShowMessage)}
                                        style={{ flexDirection: 'column', width: '50%' }}
                                    >
                                        <View style={Styles.Hr} />
                                        <MyText
                                            text={'Sinopse: ' + isDetails.sinopse.replace('Ler mais...', '')}
                                            type='subtitle'
                                            style={{ fontSize: 14 }}
                                            numberOfLines={10}
                                            ellipsizeMode='tail'
                                        />
                                    </Pressable>
                                </View>
                                <View style={Styles.Hr} />
                                <MyText
                                    text='Escolha o Player'
                                    type='subtitle'
                                    style={{ fontSize: 14, marginVertical: 5 }}
                                />
                                <View style={Styles.ContainerServices}>
                                    <Pressable
                                        style={Styles.ContainerServicesPressable}
                                        onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=mixdrop`)}
                                        onPress={() => navigation.navigate('PlayerVideo', { url: `${extractUrlVizer(data.url)}&sv=mixdrop`})}
                                    >
                                        <MyText
                                            text='Mixdrop'
                                            type='subtitle'
                                            style={{ fontSize: 14 }}
                                        />
                                    </Pressable>
                                    <Pressable
                                        style={[Styles.ContainerServicesPressable, {
                                            borderRightColor: Colors.gray.a,
                                            borderRightWidth: 1,
                                            borderLeftColor: Colors.gray.a,
                                            borderLeftWidth: 1,
                                        }]}
                                        onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=filemoon`)}
                                        onPress={() => navigation.navigate('PlayerVideo', { url: `${extractUrlVizer(data.url)}&sv=filemoon`})}
                                    >
                                        <MyText
                                            text='Filemoon'
                                            type='subtitle'
                                            style={{ fontSize: 14 }}
                                        />
                                    </Pressable>
                                    <Pressable
                                        style={Styles.ContainerServicesPressable}
                                        onLongPress={() => clipboardToast(`${extractUrlVizer(data.url)}&sv=streamtape`)}
                                        onPress={() => navigation.navigate('PlayerVideo', { url: `${extractUrlVizer(data.url)}&sv=streamtape`})}
                                    >
                                        <MyText
                                            text='Streamtape'
                                            type='subtitle'
                                            style={{ fontSize: 14 }}
                                        />
                                    </Pressable>
                                </View>
                                {isDetails.title && (
                                    <>
                                        <View style={Styles.Hr} />
                                        <MyText
                                            text={isDetails.title}
                                            type='subtitle'
                                            style={{ fontSize: 14 }}
                                            ellipsizeMode='tail'
                                        />
                                    </>
                                )}
                                <View style={Styles.Hr} />
                                <MyText
                                    text={'Duração: ' + data.time}
                                    type='subtitle'
                                    style={{ fontSize: 14 }}
                                />
                                <View style={Styles.Hr} />
                                <MyText
                                    text={isDetails.diretor.replace(/<\/?b>/g, '')}
                                    type='subtitle'
                                    style={{ fontSize: 14 }}
                                    ellipsizeMode='tail'
                                />
                                <View style={Styles.Hr} />
                                <MyText
                                    text={isDetails.elenco.replace(/<\/?b>/g, '')}
                                    type='subtitle'
                                    style={{ fontSize: 14 }}
                                    ellipsizeMode='tail'
                                />
                                <View style={Styles.Hr} />
                                <MyText
                                    text={isDetails.produtor.replace(/<\/?b>/g, '')}
                                    type='subtitle'
                                    style={{ fontSize: 14 }}
                                    ellipsizeMode='tail'
                                />
                            </View>
                            <ShowMessage
                                isModalVisible={isShowMessage}
                                setModalVisible={() => setShowMessage(!isShowMessage)}
                                Message={'Sinopse: ' + isDetails.sinopse.replace('Ler mais...', '')}
                                CopyToast={false}
                            />
                        </>
                    ) : (
                        <ActivityTemp />
                    )}
                    <WebScraping
                        isUrl={data.url}
                        isInjectedJavaScript={SCRIPT_DETAILS_MOVIES}
                        setHandleMessage={(results) => setDetails(JSON.parse(results))}
                    />
                </ScrollView>
            )}
        </>
    );
};

// Export
export default DetailsMovie;