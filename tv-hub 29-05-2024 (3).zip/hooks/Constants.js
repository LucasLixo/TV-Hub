// Vizer
export const VIZER_DOMAIN = "org";
export const VIZER_HOST = `https://vizerhd.${VIZER_DOMAIN}/`;
export const VIZER_SEARCH = `${VIZER_HOST}pesquisar/?p=`;

// Bluray
export const BLURAY_DOMAIN = "net";
export const BLURAY_HOST = `https://topfilmestorrent.${BLURAY_DOMAIN}/`;
export const BLURAY_SEARCH = `${BLURAY_HOST}?s=`;

// User Agent
export const USER_AGENT_IPHONE = "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1";
export const USER_AGENT_ANDROID = "Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36";
export const USER_AGENT_WINDOWS = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
export const USER_AGENT_MOZILLA = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0";

export const GENRES = [
    { key: 'recente', url: VIZER_HOST + 'assistir/filmes-online-2/', title: 'adicionados' },
    { key: 'animacao', url: VIZER_HOST + 'genero/filmes-de-animacao-1/', title: 'animação' },
    { key: 'aventura', url: VIZER_HOST + 'genero/filmes-de-aventura-2/', title: 'aventura' },
    { key: 'acao', url: VIZER_HOST + 'genero/filmes-de-acao-3/', title: 'ação' },
    { key: 'comedia', url: VIZER_HOST + 'genero/filmes-de-comedia-4/', title: 'comédia' },
    { key: 'crime', url: VIZER_HOST + 'genero/filmes-de-crime-5/', title: 'crime' },
    { key: 'documentario', url: VIZER_HOST + 'genero/filmes-de-documentario-6/', title: 'documentário' },
    { key: 'drama', url: VIZER_HOST + 'genero/filmes-de-drama-7/', title: 'drama' },
    { key: 'familia', url: VIZER_HOST + 'genero/filmes-de-familia-8/', title: 'família' },
    { key: 'fantasia', url: VIZER_HOST + 'genero/filmes-de-fantasia-9/', title: 'fantasia' },
    { key: 'faroeste', url: VIZER_HOST + 'genero/filmes-de-faroeste-10/', title: 'faroeste' },
    { key: 'ficcao', url: VIZER_HOST + 'genero/filmes-de-ficcao-cientifica-11/', title: 'ficção' },
    { key: 'guerra', url: VIZER_HOST + 'genero/filmes-de-guerra-12/', title: 'guerra' },
    { key: 'historia', url: VIZER_HOST + 'genero/filmes-de-historia-13/', title: 'história' },
    { key: 'misterio', url: VIZER_HOST + 'genero/filmes-de-misterio-14/', title: 'mistério' },
    { key: 'musica', url: VIZER_HOST + 'genero/filmes-de-musica-15/', title: 'música' },
    { key: 'nacional', url: VIZER_HOST + 'genero/filmes-de-nacional-16/', title: 'nacional' },
    { key: 'romance', url: VIZER_HOST + 'genero/filmes-de-romance-17/', title: 'romance' },
    { key: 'suspense', url: VIZER_HOST + 'genero/filmes-de-suspense-18/', title: 'suspense' },
    { key: 'terror', url: VIZER_HOST + 'genero/filmes-de-terror-19/', title: 'terror' },
];

export const DOMAINS = [
    VIZER_HOST,
    'accounts.google',
    'google',
    'encontre',
    'mixdrop',
    'streamtape',
    'filemoon'
];
