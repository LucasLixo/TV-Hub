import React from 'react';
import WebView from 'react-native-webview';

import { USER_AGENT_MOZILLA } from "../hooks/Constants";
import Colors from '../hooks/Colors';
import HeaderTitle from './includes/HeaderTitle';

const Config = () => {
    const configHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
            <style type="text/css">
                html, body, body * {
                    padding: 0,
                    margin: 0,
                    boxsizing: border-box;
                    color: ${Colors.text.a};
                }
                html, body {
                    padding: 20px 0,
                }
                body {
                    background: ${Colors.background.a};
                }
            </style>
        </head>
        <body>
            <ul>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
            </ul>
        </body>
        </html>
    `;

    return (
        <>
            <HeaderTitle title='Configurações' />
            <WebView
                style={{ flex: 1, backgroundColor: Colors.background.a }}
                source={{ html: configHtml }}
                userAgent={USER_AGENT_MOZILLA}
            />
        </>
    );
};

// Export
export default Config;