import React from 'react';
import { AppRegistry, Image, ImageBackground, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';

// Recursos
import { Colors } from './src/resources/Colors';

// Telas
import Anime from './src/screens/Anime';
import Movie from './src/screens/Movie';
import Serie from './src/screens/Serie';
import Config from './src/screens/Config';

// Pesquisa
import ScreenSearch from './src/screens/search/Search';

// Detalhes
import DetailsMovie from './src/screens/details/DetailsMovie';

// Player
import LoaderMovieBluray from './src/screens/loader/LoaderMovieBluray';
import LoaderMovieApi from './src/screens/loader/LoaderMovieApi';
import { SafeAreaView } from 'react-native-safe-area-context';
import IconsStyle from './src/resources/IconsStyle';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const navTheme = {
    // ...DefaultTheme,
    colors: {
        // ...DefaultTheme.colors,
        background: Colors.shadow.a,
    },
};

function BottomTabs() {

    return (
        <Tab.Navigator
            initialRouteName='Filmes'
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;

                    if (route.name === 'Animes') {
                        iconName = focused ? 'pause' : 'play';
                    } else if (route.name === 'Filmes') {
                        iconName = focused ? 'pause' : 'play';
                    } else if (route.name === 'Series') {
                        iconName = focused ? 'pause' : 'play';
                    }

                    return <IconsStyle name={iconName} size={28} color={Colors.sky.a} />;
                },
                headerShown: false,
                tabBarActiveTintColor: Colors.sky.a,
                tabBarInactiveTintColor: Colors.white,
                tabBarLabelStyle: {
                    fontWeight: 'bold',
                },
                tabBarStyle: {
                    backgroundColor: Colors.primary,
                },
            })}
        >
            <Tab.Screen name="Animes" component={Anime} />
            <Tab.Screen name="Filmes" component={Movie} />
            <Tab.Screen name="Series" component={Serie} />
        </Tab.Navigator>
    );
}

function App() {
    return (
        <NavigationContainer theme={navTheme}>
            {/* Barra de status */}
            <StatusBar
                animated={true}
                backgroundColor='transparent'
                hidden={false}
            />
            <SafeAreaView
                style={{
                    flex: 1,
                    width: '100%',
                    height: '100%',
                    backgroundColor: Colors.shadow.a,
                    position: 'relative',
                }}
            >
                <Stack.Navigator
                    screenOptions={{
                        // headerMode: 'screen',
                        headerShown: false,
                        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                    }}
                >
                    <Stack.Screen name="Main" component={BottomTabs} />
                    {/* Configurações */}
                    <Stack.Screen name="Config" component={Config} />
                    {/* Pesquisa */}
                    <Stack.Screen name="Search" component={ScreenSearch} />
                    {/* Details */}
                    <Stack.Screen name="DetailsMovie" component={DetailsMovie} />
                    {/* Player */}
                    <Stack.Screen name="LoaderMovieBluray" component={LoaderMovieBluray} />
                    <Stack.Screen name="LoaderMovieApi" component={LoaderMovieApi} />
                </Stack.Navigator>
            </SafeAreaView>
        </NavigationContainer>
    );
}

// Exportar o componente App
AppRegistry.registerComponent('App', () => App);
export default App;
