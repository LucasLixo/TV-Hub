export const Colors = {
    primary: '#232323', // #333333
    secondary: '#777777',
    card: '#444444',
    border: '#666666',
    shadow: {
        a: '#000000',
        b: '#00000080',
        c: '#000000bb',
    },
    slider: {
        a: '#DDDDDD',
        b: '#88888880',
    },
    sky: {
        a: '#3ea5ff',
        b: '#2c6596'
    },
    white: '#ffffff',
    info: '#fff93e',
    limom: '#44ff3e',
    error: '#ff3e3e',
}; 