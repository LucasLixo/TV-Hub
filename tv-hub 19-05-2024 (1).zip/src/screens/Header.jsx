import React from 'react';
import {
    View,
    Pressable,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DS from "../resources/DS";
import { Colors } from '../resources/Colors';
import IconsStyle from "../resources/IconsStyle";

const HeaderSearch = ({ type }) => {
    const navigation = useNavigation();

    const goToSearchScreen = () => {
        navigation.navigate('Search', { type: type });
    };

    const goToConfigScreen = () => {
        navigation.navigate('Config');
    };

    return (
        <View style={[DS.ModalContentInput, { justifyContent: 'flex-end' }]}>
            <Pressable
                style={[DS.ContentButton, { marginRight: 10 }]}
                onPress={() => goToSearchScreen()}
            >
                <IconsStyle name="search" size={38} color={Colors.sky.a} />
            </Pressable>
            <Pressable
                style={DS.ContentButton}
                onPress={() => goToConfigScreen()}
            >
                <IconsStyle name="config" size={36} color={Colors.sky.a} />
            </Pressable>
        </View>
    );
};

// Export
export default HeaderSearch;
