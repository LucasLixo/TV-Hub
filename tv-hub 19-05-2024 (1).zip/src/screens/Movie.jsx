import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Pressable,
    ScrollView,
} from 'react-native';
import DS from "../resources/DS";
import HeaderSearch from './Header';
import {
    getNewsMoviesApi,
    getGenreMoviesApi,
} from '../api/ApiMovie';
import IconsStyle from '../resources/IconsStyle';
import { Colors } from '../resources/Colors';
import FlatlistVertical from '../components/flatlist/FlatlistVertical';
import FlatlistVerticalLarge from '../components/flatlist/FlatlistVerticalLarge';

const Movie = () => {
    const [NewsMovies, setNewsMovies] = useState(null);
    const [GenreActionMovies, setGenreActionMovies] = useState(null);
    const [GenreDocMovies, setGenreDocMovies] = useState(null);
    const [GenreAnimationMovies, setGenreAnimationMovies] = useState(null);
    const [GenreComedyMovies, setGenreComedyMovies] = useState(null);
    const [GenreTerrorMovies, setGenreTerrorMovies] = useState(null);

    const fetchMovies = async () => {
        let data;
        // novos
        data = await getNewsMoviesApi(1);
        setNewsMovies(data.results);
        // Ação
        data = await getGenreMoviesApi(28);
        setGenreActionMovies(data.results);
        // Documentários
        data = await getGenreMoviesApi(99);
        setGenreDocMovies(data.results);
        // Animação
        data = await getGenreMoviesApi(16);
        setGenreAnimationMovies(data.results);
        // Comédia
        data = await getGenreMoviesApi(35);
        setGenreComedyMovies(data.results);
        // Terror
        data = await getGenreMoviesApi(27);
        setGenreTerrorMovies(data.results);
    }

    useEffect(() => {
        fetchMovies();
    }, []);

    return (
        <ScrollView style={DS.containerB}>
            <HeaderSearch type="movie" />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Lançamentos`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVerticalLarge data={NewsMovies} />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Ação`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVertical data={GenreActionMovies} />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Documentários`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVertical data={GenreDocMovies} />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Animação`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVertical data={GenreAnimationMovies} />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Comédia`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVerticalLarge data={GenreComedyMovies} />
            {/*  ==============================  */}
            <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={DS.TextWhite}>
                    {`Terror`}
                </Text>
                <Pressable onPress={() => console.log("teste")}>
                    <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                </Pressable>
            </View>
            <FlatlistVertical data={GenreTerrorMovies} />
        </ScrollView>
    );
};

// Export
export default Movie;