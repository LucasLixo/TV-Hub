import React, { useEffect, useState } from 'react';
import {
    Text,
    Pressable,
    ScrollView,
    TextInput,
    FlatList,
    View,
} from 'react-native';
import { useRoute } from '@react-navigation/native';
import { searchMoviesApi } from '../../api/ApiMovie';
import ModalFlatlistHorizontal from '../../components/flatlist/FlatlistHorizontal';
import { Colors } from '../../resources/Colors';
import { MOVIE_GENRE } from '../../resources/Constants';
import Styles from './SearchStyle';
import ModalToastMessage from '../../components/modal/ShowMessage';

const ScreenSearch = () => {
    const route = useRoute();
    const { type } = route.params;

    const [stringSearch, setStringSearch] = useState('');
    const [results, setResults] = useState(null);
    const [totalPages, setTotalPages] = useState(null);
    const [page, setPage] = useState(1);

    const fetchMovies = async () => {
        let data;
        // switch (type) {
        //     case 'Movie':
        //         data = await searchMoviesApi(query, page);
        //     case 'Serie':
        //         data = await searchMoviesApi(query, page);
        //     case 'Anime':
        //         data = await searchMoviesApi(query, page);
        // }
        data = await searchMoviesApi(stringSearch, page);

        setResults(data.results);
        setTotalPages(data.total_pages);
        setPage(data.page);
    }

    useEffect(() => {
        if (stringSearch) {
            fetchMovies();
        }
    }, [stringSearch, page]);

    const fetchBackPage = () => {
        setPage(prevPage => Math.max(prevPage - 1, 1));
    }

    const fetchNextPage = () => {
        setPage(prevPage => Math.min(prevPage + 1, totalPages));
    }

    const renderResults = () => {
        return (
            <FlatList
                data={MOVIE_GENRE}
                keyExtractor={(item) => item.id.toString()}
                numColumns={2}
                renderItem={({ item }) => (
                    <Pressable style={Styles.FlatListButton} onPress={() => console.log(item.name)}>
                        <Text style={Styles.FlatListButtonText} numberOfLines={1} ellipsizeMode='tail' >{item.name}</Text>
                    </Pressable>
                )}
            />
        );
    }

    return (
        <View style={{ alignItems: 'center' }}>
            <TextInput
                style={Styles.SearchTextInput}
                value={stringSearch}
                onChangeText={setStringSearch}
                placeholder="Pesquisar"
                placeholderTextColor={Colors.secondary}
                maxLength={24}
            />
            {stringSearch ? (
                <ModalFlatlistHorizontal data={results} />
            ) : (
                renderResults()
            )}
        </View>
    );
};

// Export
export default ScreenSearch;
