import { StyleSheet } from 'react-native';
import { Colors } from '../../resources/Colors';

const Styles = StyleSheet.create({
    SearchTextInput: {
        width: '100%',
        height: 40,
        fontSize: 16,
        color: Colors.white,
        paddingHorizontal: 10,
        borderBottomColor: Colors.card,
        borderBottomWidth: 1,
    },
    FlatListButton: {
        // paddingHorizontal: 15,
        // paddingVertical: 5,
        width: '45%',
        margin: '2%',
        height: 50,
        borderRadius: 10,
        backgroundColor: Colors.sky.b,
        alignItems: 'center',
        justifyContent: 'center'
    },
    FlatListButtonText: {
        color: Colors.white,
        fontSize: 18,
        fontWeight: 'bold',
    },
});

// Export
export default Styles;