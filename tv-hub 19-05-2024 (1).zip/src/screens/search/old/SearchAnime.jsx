import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import DS from "../../../resources/DS";

import ModalHeaderConfig from '../../../components/header/HeaderTitle';

const SearchAnime = () => {

    return (
        <>
            <ModalHeaderConfig title="Configurações" />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`SearchAnime`}</Text>
            </View>
        </>
    );
};

// Export
export default SearchAnime;