import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Pressable,
} from 'react-native';
import DS from "../../../resources/DS";

import ModalHeaderConfig from '../../../components/header/HeaderTitle';
import { useRoute } from '@react-navigation/native';
import { searchMoviesApi } from '../../../api/ApiMovie';
import ModalFlatlistHorizontal from '../../../components/flatlist/FlatlistHorizontal';
import IconsStyle from '../../../resources/IconsStyle';
import { Colors } from '../../../resources/Colors';

const SearchMovie = () => {
    const route = useRoute();
    const { query } = route.params;

    // const [totalResults, setTotalResults] = useState(null);
    const [results, setResults] = useState(null);
    const [totalPages, setTotalPages] = useState(null);
    const [page, setPage] = useState(1);

    const fetchMovies = async () => {
        let data;
        data = await searchMoviesApi(query, page);

        // setTotalResults(data.total_results);
        setResults(data.results);
        setTotalPages(data.total_pages);
        setPage(data.page);
    }

    useEffect(() => {
        fetchMovies();
    }, [page]);

    const fetchBackPage = () => {
        // setPage(prevPage => prevPage - 1);
        setPage(prevPage => Math.max(prevPage - 1, 1));
    }
    const fetchNextPage = () => {
        // setPage(prevPage => prevPage + 1);
        setPage(prevPage => Math.min(prevPage + 1, totalPages));
    }

    return (
        <>
            <ModalHeaderConfig title={query || null} />
            <View style={[DS.containerB, { alignItems: 'center' }]}>
                <ModalFlatlistHorizontal data={results} />
                <View style={{ width: '90%', borderTopColor: Colors.secondary, borderTopWidth: 1, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Text style={{ fontSize: 20, color: Colors.secondary }}>{`0`}</Text>
                    <Pressable onPress={() => fetchBackPage()}>
                        <IconsStyle name="arrowLeft" size={48} color={Colors.sky.a} />
                    </Pressable>
                    <Text style={{ fontSize: 24, color: Colors.sky.b }}>{page}</Text>
                    <Pressable onPress={() => fetchNextPage()}>
                        <IconsStyle name="arrowRight" size={48} color={Colors.sky.a} />
                    </Pressable>
                    <Text style={{ fontSize: 20, color: Colors.secondary }}>{totalPages}</Text>
                </View>
            </View>
        </>
    );
};

// Export
export default SearchMovie;