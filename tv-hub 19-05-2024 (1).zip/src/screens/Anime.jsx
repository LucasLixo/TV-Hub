import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import DS from "../resources/DS";
import HeaderSearch from './Header';

const Anime = () => {

    return (
        <>
            <HeaderSearch type='Anime' />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Anime`}</Text>
            </View>
        </>
    );
};

// Export
export default Anime;