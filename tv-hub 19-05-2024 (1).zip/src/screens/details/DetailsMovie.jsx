import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Image,
    Pressable,
} from 'react-native';
import DS from "../../resources/DS";
import ModalHeaderConfig from '../../components/header/HeaderTitle';
import { getMovieByIdApi } from '../../api/ApiMovie';
import { useRoute } from '@react-navigation/native';
import ModalToastMessage from '../../components/modal/ShowMessage';
import { BASE_PATH_IMG, MOVIE_SERVICES } from '../../resources/Constants';
import Styles from './DetailsStyle';
import IconsStyle from '../../resources/IconsStyle';
import { Colors } from '../../resources/Colors';
import { useNavigation } from '@react-navigation/native';
import ModalToastImage from '../../components/modal/ShowImage';
import ModalDropdown from '../../components/modal/Dropdown';
import { clipboardToast, encodeWithPlus } from '../../resources/Functions';
import ModalHeaderIcon from '../../components/header/HeaderIcon';

const DetailsMovie = () => {

    const route = useRoute();
    const { idMovie } = route.params;

    const [DetailsMovie, setDetailsMovie] = useState(null);
    const [isModalToastMessage, setModalToastMessage] = useState(false);
    const [isModalToastImage, setModalToastImage] = useState(false);
    const [isModalDropdown, setModalDropdown] = useState(false);
    const [isSelectedServiceName, setSelectedServiceName] = useState(MOVIE_SERVICES[0].name);

    const [SelectedServicesId, setSelectedServicesId] = useState(MOVIE_SERVICES[0].id);
    /*  ==============================  */
    const fetchMovies = async () => {
        let data;
        data = await getMovieByIdApi(idMovie);
        setDetailsMovie(data);
    }

    useEffect(() => {
        fetchMovies();
    }, [idMovie]);

    useEffect(() => {
        setSelectedServiceName(MOVIE_SERVICES[SelectedServicesId].name);
    }, [SelectedServicesId]);

    /*  ==============================  */
    const navigation = useNavigation();
    const playerMovie = () => {
        let NavigateUrl;
        let NavigateLoader;
        switch (SelectedServicesId) {
            case '1':
                navigation.navigate('LoaderMovieApi', { dataArray: `${MOVIE_SERVICES[SelectedServicesId].url}${DetailsMovie.id}-dub#MA==` });
                break;
            case '3':
                navigation.navigate('LoaderMovieBluray', { dataArray: `${MOVIE_SERVICES[SelectedServicesId].url}${encodeWithPlus(DetailsMovie.title || DetailsMovie.original_title)}` });
                break;
            default:
                navigation.navigate('LoaderMovieApi', { dataArray: `${MOVIE_SERVICES[SelectedServicesId].url}${DetailsMovie.imdb_id}` });
                break;
            }
    }

    /*  ==============================  */
    const infoAbout = `
        \n* Warezcdn | Superflixapi | Embedder - 480p a 1080p, pode ter anúncios
        \n* Bluray - Maior Qualidade, mais somente se o filme tiver Bluray
    `;

    return (
        <>
        <ModalHeaderIcon icon='about' name={infoAbout} />
            <View style={DS.containerB}>
                <View style={Styles.ImageBackdrop}>
                    {/*  ==============================  */}
                    {DetailsMovie && DetailsMovie.poster_path ? (
                        <Pressable onPress={() => setModalToastImage(!isModalToastImage)}>
                            <Image
                                source={{ uri: `${BASE_PATH_IMG}/w1280${DetailsMovie.poster_path}` }}
                                style={Styles.Image}
                            />
                        </Pressable>
                    ) : (
                        <View style={[Styles.Image, { backgroundColor: Colors.secondary }]} />
                    )}
                    {/*  ==============================  */}
                    <View style={{ width: '50%', height: '100%' }}>
                        <Pressable onLongPress={() => clipboardToast(DetailsMovie ? DetailsMovie.title || DetailsMovie.original_title : '')}>
                            <Text style={Styles.TextTitle}>
                                {DetailsMovie ? DetailsMovie.title || DetailsMovie.original_title : ''}
                            </Text>
                        </Pressable>
                        <Pressable onLongPress={() => clipboardToast(DetailsMovie.release_date)}>
                            <Text style={Styles.TextInfo} numberOfLines={1} ellipsizeMode='tail'>
                                {DetailsMovie ? `Lançamento: ` + DetailsMovie.release_date : ''}
                            </Text>
                        </Pressable>
                        <Pressable onLongPress={() => clipboardToast(DetailsMovie.imdb_id)}>
                            <Text style={Styles.TextInfo} numberOfLines={1} ellipsizeMode='tail'>
                                {DetailsMovie ? `IMDB: ` + DetailsMovie.imdb_id : ''}
                            </Text>
                        </Pressable>
                        <Pressable onLongPress={() => clipboardToast(DetailsMovie.id)}>
                            <Text style={Styles.TextInfo} numberOfLines={1} ellipsizeMode='tail'>
                                {DetailsMovie ? `TMDB: ` + DetailsMovie.id : ''}
                            </Text>
                        </Pressable>
                        {DetailsMovie && DetailsMovie.tagline ? (
                            <>
                                <View style={Styles.ViewHr} />
                                <Text style={Styles.TextInfo} numberOfLines={2} ellipsizeMode='tail'>
                                    {DetailsMovie.tagline}
                                </Text>
                            </>
                        ) : null}
                    </View>
                </View>
                <View style={Styles.ViewHr} />
                {/*  ==============================  */}
                <View style={Styles.ContentDropdown}>
                    <Text style={Styles.TextOverview}>{`Servidor`}</Text>
                    <Pressable
                        style={[Styles.ButtonPlay, { marginHorizontal: 0, width: '60%', backgroundColor: Colors.card, justifyContent: 'space-around' }]}
                        onPress={() => setModalDropdown(!isModalDropdown)}
                    >
                        <Text style={{ color: Colors.white, fontWeight: 'bold' }}>
                            {isSelectedServiceName}
                        </Text>
                    </Pressable>
                </View>
                {/*  ==============================  */}
                <View style={Styles.ViewHr} />
                <Pressable
                    style={Styles.ButtonPlay}
                    onPress={() => playerMovie()}
                >
                    <>
                        <IconsStyle name='play' size={26} color={Colors.white} />
                        <Text style={{ color: Colors.white, fontWeight: 'bold' }}>{`  Play`}</Text>
                    </>
                </Pressable>
                {/*  ==============================  */}
                {DetailsMovie && DetailsMovie.overview && (
                    <>
                        <View style={Styles.ViewHr} />
                        <Pressable
                            onPress={() => setModalToastMessage(!isModalToastMessage)}
                        >
                            <Text style={Styles.TextOverview} numberOfLines={5} ellipsizeMode='tail'>
                                {DetailsMovie ? `Sinopse: ${DetailsMovie.overview}` : ''}
                            </Text>
                        </Pressable>
                    </>
                )}
            </View>
            {/*  ==============================  */}
            <ModalDropdown
                isModalVisible={isModalDropdown}
                setModalVisible={() => setModalDropdown(!isModalDropdown)}
                dataArray={MOVIE_SERVICES}
                onSelectItem={(itemId) => setSelectedServicesId(itemId)}
            />
            {/*  ==============================  */}
            <ModalToastMessage
                isModalVisible={isModalToastMessage}
                setModalVisible={() => setModalToastMessage(!isModalToastMessage)}
                Message={DetailsMovie ? `Sinopse: ` + DetailsMovie.overview : ''}
            />
            {DetailsMovie && DetailsMovie.poster_path ? (
                <ModalToastImage
                    isModalVisible={isModalToastImage}
                    setModalVisible={() => setModalToastImage(!isModalToastImage)}
                    imageURL={`${BASE_PATH_IMG}/w1280${DetailsMovie.poster_path}`}
                />
            ) : null}
        </>
    );
};

// Export
export default DetailsMovie;