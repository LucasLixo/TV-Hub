import { StyleSheet } from 'react-native';
import { Colors } from '../../resources/Colors';

const Styles = StyleSheet.create({
    ImageBackdrop: {
        width: '100%',
        height: 200,
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'flex-start'
    },
    Image: {
        width: 140,
        height: 200,
        borderRadius: 10,
    },
    TextTitle:{
        textAlign: 'center',
        fontSize: 14,
        fontWeight: 'bold',
        color: Colors.white,
        marginBottom: 10,
    },
    TextInfo: {
        textAlign: 'center',
        fontSize: 10,
        color: Colors.slider.a,
    },
    ViewHr: {
        marginVertical: 10,
        borderTopColor: Colors.slider.b,
        borderTopWidth: 1,
    },
    TextOverview: {
        textAlign: 'center',
        fontSize: 12,
        color: Colors.slider.a,
    },
    ButtonPlay: {
        position: 'relative',
        marginHorizontal: 'auto',
        width: '90%',
        paddingVertical: 5,
        backgroundColor: Colors.sky.b,
        flexDirection: 'row',
        justifyContent: 'center',
        borderRadius: 10
    },
    ButtonPlayText: {
        color: Colors.white,
        fontSize: 14,
        textTransform: 'capitalize'
    },
    ContentDropdown: {
        width: '90%', 
        marginHorizontal: 'auto', 
        flexDirection: 'row', 
        alignItems: 'center', 
        justifyContent: 'space-between',
    },
});

// Export
export default Styles;