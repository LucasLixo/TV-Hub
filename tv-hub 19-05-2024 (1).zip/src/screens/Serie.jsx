import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import DS from "../resources/DS";

import HeaderSearch from './Header';

const Séries = () => {

    return (
        <>
            <HeaderSearch type='Serie' />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Série`}</Text>
            </View>
        </>
    );
};

// Export
export default Séries;