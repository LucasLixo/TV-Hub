import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useRoute } from '@react-navigation/native';
import WebView from 'react-native-webview';
import * as ScreenOrientation from 'expo-screen-orientation';
import { StatusBar } from 'expo-status-bar';
import { USER_AGENT_IPHONE } from '../../resources/Constants';
import PlayerVideo from './PlayerVideo';
import { Colors } from '../../resources/Colors';

const LoaderMovieBluray = () => {
    const route = useRoute();
    const { dataArray } = route.params;
    const [isInfo, setInfo] = useState(null);
    const [extractedHref01, setExtractedHref01] = useState(null);
    const [extractedHref02, setExtractedHref02] = useState(null);
    const webViewRef01 = useRef(null);
    const webViewRef02 = useRef(null);

    // useEffect(() => {
    //     if (dataArray) {
    //         setInfo({
    //             title: dataArray.Title,
    //             link: MOVIE_SERVICES[dataArray.ServicesId].url + encodeWithPlus(dataArray.Title),
    //             imdb: dataArray.ImdbId,
    //             tmdb: dataArray.TmdbId,
    //         });
    //     }
    // }, [dataArray]);

    useEffect(() => {
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
        return () => {
            ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        };
    }, []);

    const injectedJavaScript01 = `
    (function() {
        const linkElement = document.querySelector("html > body > div#container > div#main > div#content > article > header.entry-header.cf > h2.entry-title > a[href]");
        if (linkElement) {
            window.ReactNativeWebView.postMessage(linkElement.href);
        } else {
            window.ReactNativeWebView.postMessage("Not Found");
        }
    })();
    true;
    `;

    const injectedJavaScript02 = `
    (function() {
        const linkElement = document.querySelector("html > body > div#container > div#main > div#content > article > div.entry-content.cf > p > a[href] > img.alignnone.size-full.wp-image-177776.aligncenter");
        if (linkElement) {
            window.ReactNativeWebView.postMessage(linkElement.parentElement.href);
        } else {
            window.ReactNativeWebView.postMessage("Not Found");
        }
    })();
    true;
    `;

    const handleMessage01 = (event) => {
        setExtractedHref01(event.nativeEvent.data);
    };

    const handleMessage02 = (event) => {
        setExtractedHref02(event.nativeEvent.data);
    };

    const verifyUrl = (url) => {
        return url !== 'Not Found' && url !== null;
    };

    return (
        <>
            <StatusBar
                animated={true}
                backgroundColor='transparent'
                hidden={true}
            />
            {dataArray && !verifyUrl(extractedHref02) && (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator
                        color={Colors.sky.a}
                        size="large"
                        hidesWhenStopped={true}
                        style={{ position: 'absolute', zIndex: 10 }}
                    />
                    <WebView
                        ref={webViewRef01}
                        source={{ uri: dataArray }}
                        injectedJavaScript={injectedJavaScript01}
                        onMessage={handleMessage01}
                        userAgent={USER_AGENT_IPHONE}
                        style={{ display: 'none', width: 0, height: 0 }}
                        />
                    {extractedHref01 && (
                        <WebView
                            ref={webViewRef02}
                            source={{ uri: extractedHref01 }}
                            injectedJavaScript={injectedJavaScript02}
                            onMessage={handleMessage02}
                            userAgent={USER_AGENT_IPHONE}
                            style={{ display: 'none', width: 0, height: 0 }}
                        />
                    )}
                </View>
            )}
            {verifyUrl(extractedHref02) && <PlayerVideo DataUrl={extractedHref02} />}
        </>
    );
};

// Export
export default LoaderMovieBluray;
