import React, { useEffect, useState } from 'react';
import { WebView } from 'react-native-webview';
import { Pressable } from 'react-native';
import { USER_AGENT_WINDOWS } from '../../resources/Constants';
import Styles from './PlayerStyle';
import { clipboardToast } from '../../resources/Functions';
import { Colors } from '../../resources/Colors';
import LoaderErro from './LoaderErro';

const PlayerVideo = ({ DataUrl }) => {
    const [loadingError, setLoadingError] = useState(false);
    const [textError, setTextError] = useState(null);

    const handleErroStateChange = (errorMessage) => {
        setLoadingError(true);
        setTextError(errorMessage);
        console.log(errorMessage);
    };

    useEffect(() => {
        // setLoadingError(DataUrl.startsWith("https://"));
        // console.log(DataUrl);
    }, [DataUrl]);

    return (
        <Pressable
            onLongPress={() => clipboardToast(DataUrl)}
            style={[Styles.WebView, { position: 'relative' }]}
        >
            <WebView
                source={{ uri: DataUrl }}
                style={[Styles.WebView, { zIndex: 1, backgroundColor: Colors.shadow.a }]}
                javaScriptEnabled={true}
                javaScriptCanOpenWindowsAutomatically={false}
                domStorageEnabled={true}
                onError={(syntheticEvent) => handleErroStateChange(syntheticEvent.nativeEvent.description)}
                // onShouldStartLoadWithRequest={request => {
                //     if (request.url.includes('https')) {
                //         return false;
                //     } else return true;
                // }}
                setSupportMultipleWindows={false}
                startInLoadingState={false}
                userAgent={USER_AGENT_WINDOWS}
            />
            {loadingError && (
                <LoaderErro textError={textError} />
            )}
        </Pressable>
    );
};

// Export
export default PlayerVideo;
