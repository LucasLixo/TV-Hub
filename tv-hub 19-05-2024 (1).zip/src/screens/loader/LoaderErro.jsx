import React from 'react';
import {
    Text,
    Pressable,
} from 'react-native';
import DS from "../../resources/DS";
import { useNavigation } from '@react-navigation/native';
import { Colors } from '../../resources/Colors';

const LoaderErro = ({ textError }) => {
    const navigation = useNavigation();

    return (
        <Pressable
            style={{
                width: '100%',
                height: '100%',
                position: 'absolute',
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: Colors.shadow.a
            }}
            onPressOut={() => navigation.goBack()}
        >
            <Text style={[DS.TextTitle, { fontSize: 18, textAlign: 'center' }]}>
                {`Erro`}
            </Text>
            {textError && (
                <Text style={[DS.TextWhite, { fontSize: 12, textAlign: 'center' }]}>
                    {textError}
                </Text>
            )}
        </Pressable>
    );
};

// Export
export default LoaderErro;