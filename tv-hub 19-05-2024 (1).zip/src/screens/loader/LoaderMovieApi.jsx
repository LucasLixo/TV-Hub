import React, { useEffect } from 'react';
import { useRoute } from '@react-navigation/native';
import * as ScreenOrientation from 'expo-screen-orientation';
import { StatusBar } from 'expo-status-bar';
import PlayerVideo from './PlayerVideo';
import { View } from 'react-native';

const LoaderMovieApi = () => {
    const route = useRoute();
    const { dataArray } = route.params;

    useEffect(() => {
        // console.log(dataArray);
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
        return () => {
            ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        };
    }, []);

    return (
        <>
            <StatusBar
                animated={true}
                backgroundColor='transparent'
                hidden={true}
            />
            {dataArray ? (
                <PlayerVideo DataUrl={dataArray} />
            ) : (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator
                        color={Colors.sky.a}
                        size="large"
                        hidesWhenStopped={true}
                        style={{ position: 'absolute', zIndex: 10 }}
                    />
                </View>
            )}
        </>
    );
};

// Export
export default LoaderMovieApi;
