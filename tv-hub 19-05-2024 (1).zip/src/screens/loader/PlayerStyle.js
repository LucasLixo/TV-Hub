import { StyleSheet } from 'react-native';
import { Colors } from '../../resources/Colors';

const Styles = StyleSheet.create({
    WebView: {
        flex: 1, 
        width: '100%', 
        height: '100%',
        position: 'absolute',
    },
});

// Export
export default Styles;