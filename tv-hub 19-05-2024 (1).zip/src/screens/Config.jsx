import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import DS from "../resources/DS";

import ModalHeaderConfig from '../components/header/HeaderTitle';
import WebView from 'react-native-webview';
import { USER_AGENT_MOZILLA } from '../resources/Constants';
import { Colors } from '../resources/Colors';

const Config = () => {
    const configHtml = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
            <style>
                html, body, body * {
                    padding: 0,
                    margin: 0,
                    boxsizing: border-box;
                    color: ${Colors.white};
                }
                html, body {
                    padding: 20px 0,
                }
                body {
                    background: ${Colors.shadow.a};
                }
            </style>
        </head>
        <body>
            <ul>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
                <li>ou</li>
            </ul>
        </body>
        </html>
    `;

    return (
        <>
            <ModalHeaderConfig title="Configurações" />
            <View style={DS.containerB}>
                <WebView
                    source={{ html: configHtml }}
                    userAgent={USER_AGENT_MOZILLA}
                />
            </View>
        </>
    );
};

// Export
export default Config;