import React from 'react';
import {
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import DS from "../../resources/DS";
import { BASE_PATH_IMG } from '../../resources/Constants';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '../../resources/Colors';

const FlatlistVerticalLarge = ({ data }) => {
    const navigation = useNavigation();

    const DetailsMovie = (id) => {
        navigation.navigate('DetailsMovie', { idMovie: id });
    }

    return (
        <FlatList
            data={data || null}
            key="#"
            keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item, index }) => (
                <Pressable
                    key={index}
                    style={DS.MovieLarge}
                    onPress={() => {
                        DetailsMovie(item.id);
                    }}
                >
                    <>
                        {item.poster_path ? (
                            <Image source={{ uri: `${BASE_PATH_IMG}/w500${item.backdrop_path}` }} style={DS.Image} />
                        ) : (
                            <Text style={[DS.TextInfo, { fontSize: 10, textAlign: 'center' }]}>{item.title || item.original_title}</Text>
                        )}
                        <LinearGradient colors={[ 'transparent', 'black']} style={{position: 'absolute', width: '100%', height: '100%', justifyContent: 'flex-end', paddingLeft: 15}}>
                            <Text numberOfLines={1} ellipsizeMode='tail' style={{ color: Colors.white, fontSize: 16, textAlign: 'left' }}>
                                {item ? item.title : item.original_title}
                            </Text>
                            <Text numberOfLines={1} ellipsizeMode='tail' style={{ color: Colors.white + 'CC', fontSize: 12, textAlign: 'left' }}>
                                {item ? item.release_date : ''}
                                {item && item.video ? ' | adulto' : ''}
                            </Text>
                        </LinearGradient>
                    </>
                </Pressable>
            )}
        />
    );
};

// Export
export default FlatlistVerticalLarge;