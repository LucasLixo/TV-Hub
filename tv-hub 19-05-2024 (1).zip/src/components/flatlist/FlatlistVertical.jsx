import React from 'react';
import {
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import DS from "../../resources/DS";
import { BASE_PATH_IMG } from '../../resources/Constants';
import { useNavigation } from '@react-navigation/native';
import { Colors } from '../../resources/Colors';

const FlatlistVertical = ({ data }) => {
    const navigation = useNavigation();

    const DetailsMovie = (id) => {
        navigation.navigate('DetailsMovie', { idMovie: id });
    }

    return (
        <FlatList
            data={data || null}
            key="#"
            keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item, index }) => (
                <Pressable
                    key={index}
                    style={DS.Movie}
                    onPress={() => {
                        DetailsMovie(item.id);
                    }}
                >
                    <>
                        <Text style={{ position: 'absolute', fontSize: 8, left: 10, bottom: 10, color: Colors.sky.a, zIndex: 10 }}>
                            {item && item.video ? ' | adulto' : ''}
                        </Text>
                        {item.poster_path ? (
                            <Image source={{ uri: `${BASE_PATH_IMG}/w500${item.poster_path}` }} style={DS.Image} />
                        ) : (
                            <Text style={[DS.TextInfo, { fontSize: 10, textAlign: 'center' }]}>{item.title || item.original_title}</Text>
                        )}
                    </>
                </Pressable>
            )}
        />
    );
};

// Export
export default FlatlistVertical;