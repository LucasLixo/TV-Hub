import React from 'react';
import {
    Modal,
    Pressable,
    Text,
    View,
} from 'react-native';
import DS from "../../resources/DS";
import { FlatList } from 'react-native-gesture-handler';
import Styles from './DropdownStyle';

const ModalDropdown = ({ isModalVisible, setModalVisible, dataArray, onSelectItem }) => {
    const handleClose = () => {
        setModalVisible();
    };

    const handleCloseOn = (itemId) => {
        setModalVisible();
        onSelectItem(itemId);
    };
    
    return (
        <Modal
            animationType='slide'
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={[DS.ModalContentShadow, { justifyContent: 'flex-end' }]}
                onPress={() => handleClose()}
            >
                <View style={Styles.contentDropdown}>
                    <Text style={[DS.TextWhite, Styles.titleDropdown]}>
                        {`Servidores`}
                    </Text>
                    <FlatList
                        data={dataArray || null}
                        key="#"
                        keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
                        numColumns={1}
                        style={{ width: '100%', height: '100%' }}
                        renderItem={({ item, index }) => (
                            <Pressable
                                key={index}
                                style={{
                                    width: '100%',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                }}
                                onPress={() => handleCloseOn(item.id)}
                            >
                                <Text style={Styles.textDropdown}>
                                    {item.name}
                                </Text>
                            </Pressable>
                        )}
                    />
                </View>
            </Pressable>
        </Modal>
    );
};

// Export
export default ModalDropdown;