import { StyleSheet } from 'react-native';
import { Colors } from '../../resources/Colors';

const Styles = StyleSheet.create({
    contentDropdown: {
        width: '80%', 
        height: '40%', 
        overflow: 'hidden'
    },
    titleDropdown: {
        textAlign: 'center', 
        backgroundColor: Colors.sky.b, 
        borderTopLeftRadius: 15, 
        borderTopRightRadius: 15,
        borderBottomColor: Colors.secondary,
        borderBottomWidth: 1,
        paddingVertical: 5,
        marginBottom: 0
    },
    textDropdown: {
        width: '100%',
        textAlign: 'center',
        fontSize: 14,
        fontWeight: 'bold',
        paddingVertical: 10,
        backgroundColor: Colors.primary,
        borderBottomColor: Colors.secondary,
        borderBottomWidth: 1,
        color: Colors.white,
    },
});

// Export
export default Styles;