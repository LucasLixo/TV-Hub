import React, { useState } from 'react';
import {
    Pressable,
    View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DS from "../../resources/DS";
import { Colors } from '../../resources/Colors';
import IconsStyle from "../../resources/IconsStyle";
import ModalToastMessage from '../modal/ShowMessage';

const ModalHeaderIcon = ({ icon, name }) => {
    const [isModalToastMessage, setModalToastMessage] = useState(false);
    const navigation = useNavigation();

    const goToScreen = () => {
        navigation.navigate('Filmes');
    };

    return (
        <>
            <View style={[DS.ModalContentInput, { alignItems: 'center' }]}>
                <Pressable
                    style={DS.ContentButton}
                    onPress={() => goToScreen()}
                >
                    <IconsStyle name="arrowLeft" size={36} color={Colors.sky.a} />
                </Pressable>
                <Pressable
                    style={[DS.TextTitle, { alignItems: 'flex-end' }]}
                    onPress={() => setModalToastMessage(!isModalToastMessage)}
                >
                    <IconsStyle name={icon} size={36} color={Colors.sky.a} />
                </Pressable>
                {/*  ==============================  */}
            </View>
            <ModalToastMessage
                isModalVisible={isModalToastMessage}
                setModalVisible={() => setModalToastMessage(!isModalToastMessage)}
                Message={name}
            />
        </>
    );
};

// Export
export default ModalHeaderIcon;