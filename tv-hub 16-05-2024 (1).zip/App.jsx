import React from 'react';
import { Pressable, AppRegistry, Text } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';

// Recursos
import IconsStyle from './src/resources/IconsStyle';
import { Colors } from './src/resources/Colors';

// Telas
import Anime from './src/screens/Anime';
import Movie from './src/screens/Movie';
import Serie from './src/screens/Serie';
import Config from './src/screens/Config';
import SearchMovie from './src/screens/SearchMovie';
import SearchAnime from './src/screens/SearchAnime';
import SearchSerie from './src/screens/SearchSerie';
import PlayerMovie from './src/screens/PlayerMovie';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function BottomTabs() {
    return (
        <Tab.Navigator
            initialRouteName='Filmes'
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    return null;
                },
                headerShown: false,
                tabBarActiveTintColor: Colors.sky.a,
                tabBarInactiveTintColor: Colors.white,
                tabBarLabelStyle: {
                    fontSize: 16,
                    fontWeight: 'bold',
                },
                tabBarIconStyle: {
                    display: 'none',
                },
                tabBarStyle: {
                    backgroundColor: Colors.primary,
                },
            })}
        >
            <Tab.Screen name="Animes" component={Anime} />
            <Tab.Screen name="Filmes" component={Movie} />
            <Tab.Screen name="Series" component={Serie} />
        </Tab.Navigator>
    );
}

function App() {
    return (
        <NavigationContainer>
            {/* Barra de status */}
            <StatusBar
                animated={true}
                backgroundColor={Colors.shadow.a}
                hidden={false}
            />
            <Stack.Navigator
                screenOptions={{
                    // headerMode: 'screen',
                    headerShown: false,
                    cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
                }}
            >
                <Stack.Screen name="Main" component={BottomTabs} />
                <Stack.Screen name="Config" component={Config} />
                <Stack.Screen name="SearchMovie" component={SearchMovie} />
                <Stack.Screen name="SearchAnime" component={SearchAnime} />
                <Stack.Screen name="SearchSerie" component={SearchSerie} />
                <Stack.Screen name="PlayerMovie" component={PlayerMovie} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}

// Exportar o componente App
AppRegistry.registerComponent('App', () => App);
export default App;
