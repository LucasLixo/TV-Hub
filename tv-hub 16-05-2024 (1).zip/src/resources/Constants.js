import * as React from "react";
import {
    ToastAndroid,
    /* Linking, */
} from "react-native";
import * as Clipboard from 'expo-clipboard';

export const API_KEY = "9bd0b9c5408935f36fb2c60e149f2779";
export const API_HOST = "https://api.themoviedb.org/3";
export const LANG = "pt";
export const BASE_PATH_IMG = "https://image.tmdb.org/t/p";

export const clipboardToast = async (Clip) => {
    await Clipboard.setStringAsync(Clip);
    ToastAndroid.show(`Copiado!`, ToastAndroid.SHORT)
}

export const clipboardImageToast = async (Clip) => {
    await Clipboard.setStringAsync(Clip);
    ToastAndroid.show(`Copiado!`, ToastAndroid.SHORT)
}