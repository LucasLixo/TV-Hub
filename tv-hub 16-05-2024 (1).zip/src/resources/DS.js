import { StyleSheet } from 'react-native';
import { Colors } from './Colors';

const DS = StyleSheet.create({
    TextCenter: {
        width: '100%',
        textAlign: 'center',
        textAlignVertical: 'center',
        color: Colors.white,
        fontSize: 12,
    },
    TextTitle: {
        color: Colors.sky.a,
        width: '80%',
        textAlign: 'right',
        fontWeight: 'bold',
        textTransform: 'capitalize',
        fontSize: 16,
    },
    TextWhite: {
        color: Colors.white,
        fontSize: 18,
        marginVertical: 10,
    },
    TextInfo: {
        color: Colors.white,
        fontSize: 12,
    },
    /* ----- */
    containerA: {
        backgroundColor: '#000000',
        width: '100%',
        height: '100%',
    },
    containerB: {
        width: '100%',
        height: '95%',
        paddingLeft: 10,
    },
    Movie: {
        width: 140,
        height: 200,
        marginRight: 20,
        marginBottom: 20,
        justifyContent: "center",
        alignItems: "center",
    },
    Image: {
        width: "100%",
        height: "100%",
    },
    /* ----- */
    ModalContentShadow: {
        flex: 1,
        width: '100%',
        height: '100%',
        position: 'absolute',
        zIndex: -1,
        backgroundColor: Colors.shadow.b,
    },
    /* ----- */
    ModalContentInput: {
        width: '100%',
        height: '5%',
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
    ContentInput: {
        width: '80%', 
        height: '100%',
        color: Colors.white,
        paddingHorizontal: 5,
        borderBottomColor: Colors.sky.a,
        borderBottomWidth: 2,
    },
    ContentButton: {
        width: '11%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    /* ----- */
    ModalContentDetails: {
        width: '100%',
        height: 250,
        marginTop: 15,
        flexDirection: 'row',
        position: 'relative,'
    },
    ModalContentDetailsImage: {
        width: '100%',
        height: '100%',
        position: 'absolute',
    }
});

// Export
export default DS;