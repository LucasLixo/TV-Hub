import React, { useState } from 'react';
import {
    Text,
    Image,
    Pressable,
    FlatList,
} from 'react-native';
import DS from "../resources/DS";
import { BASE_PATH_IMG } from '../resources/Constants';
import { useNavigation } from '@react-navigation/native';

const ModalFlatlistHorizontal = ({ data }) => {
    const navigation = useNavigation();

    const playerMovie = (id) => {
        navigation.navigate('PlayerMovie', { idMovie: id });
    }

    return (
        <FlatList
            data={data || null}
            key="#"
            keyExtractor={(item, index) => "#" + item.id.toString() || "#" + index.toString()}
            numColumns={2}
            renderItem={({ item, index }) => (
                <Pressable
                    key={index}
                    style={DS.Movie}
                    onPress={() => {
                        playerMovie(item.id);
                    }}
                >
                    {item.poster_path ? (
                        <Image source={{ uri: `${BASE_PATH_IMG}/w500${item.poster_path}` }} style={DS.Image} />
                    ) : (
                        <Text style={[DS.TextInfo, { fontSize: 10, textAlign: 'center' }]}>{item.title || item.original_title}</Text>
                    )}
                </Pressable>
            )}
        />
    );
};

// Export
export default ModalFlatlistHorizontal;