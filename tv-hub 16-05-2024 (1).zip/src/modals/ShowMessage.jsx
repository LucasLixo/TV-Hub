import React from "react";
import {
    Modal,
    Pressable,
    Text,
} from "react-native";
import DS from "../resources/DS";
import { Colors } from "../resources/Colors";
import { clipboardToast } from "../resources/Constants";

const ModalToastMessage = ({ isModalVisible, setModalVisible, Message }) => {
    const handleClose = () => {
        setModalVisible();
    };

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={[DS.ModalContentShadow, { backgroundColor: Colors.shadow.c, justifyContent: 'center', alignItems: 'center', padding: 20 }]}
                onPress={() => handleClose()}
                onLongPress={() => clipboardToast(Message || '')}
            >
                <Text style={{ flexWrap: 'wrap', textAlign: 'center', color: Colors.white }}>{Message || ''}</Text>
            </Pressable>
        </Modal>
    );
};

export default ModalToastMessage;