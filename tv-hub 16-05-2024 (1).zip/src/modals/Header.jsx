import React, { useState } from 'react';
import {
    Pressable,
    TextInput,
    KeyboardAvoidingView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DS from "../resources/DS";
import { Colors } from '../resources/Colors';
import IconsStyle from "../resources/IconsStyle";

const ModalHeader = ({ type }) => {
    const [text, setText] = useState('');
    const navigation = useNavigation();

    const goToScreen = () => {
        navigation.navigate('Config'); 
    };

    const goToSearch = () => {
        if (type === 'movie') {
            navigation.navigate('SearchMovie', { query: text }); 
        } else if (type === 'anime') {
            navigation.navigate('SearchAnime', { query: text }); 
        } else if (type === 'serie') {
            navigation.navigate('SearchSerie', { query: text }); 
        }
    };

    return (
        <KeyboardAvoidingView style={DS.ModalContentInput}>
            <TextInput
                style={DS.ContentInput}
                placeholder="Pesquisar"
                placeholderTextColor={Colors.secondary}
                value={text}
                onChangeText={setText} // Atualiza o estado com o texto digitado
                onSubmitEditing={goToSearch} // Chama a função de busca ao pressionar Enter
                maxLength={24}
            />
            <Pressable
                style={DS.ContentButton}
                onPress={goToScreen}
            >
                <IconsStyle name="config" size={36} color={Colors.sky.a} />
            </Pressable>
        </KeyboardAvoidingView>
    );
};

// Export
export default ModalHeader;
