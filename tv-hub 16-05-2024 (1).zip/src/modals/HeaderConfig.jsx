import React from 'react';
import {
    Pressable,
    View,
    Text,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DS from "../resources/DS";
import { Colors } from '../resources/Colors';
import IconsStyle from "../resources/IconsStyle";

const ModalHeaderConfig = ({ title }) => {
    const navigation = useNavigation();

    const goToScreen = () => {
        navigation.navigate('Filmes'); 
    };

    return (
        <View style={[DS.ModalContentInput, { alignItems: 'center' }]}>
            <Pressable
                style={DS.ContentButton}
                onPress={() => goToScreen()}
            >
                <IconsStyle name="arrowLeft" size={36} color={Colors.sky.a} />
            </Pressable>
            <Text
                numberOfLines={1}
                ellipsizeMode="tail"
                style={ DS.TextTitle }
            >
                {title || ''}
            </Text>
        </View>
    );
};

// Export
export default ModalHeaderConfig;