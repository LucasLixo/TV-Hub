import React from 'react';
import {
    View,
    Text,
    Image,
    ImageBackground,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DS from "../resources/DS";
import { Colors } from '../resources/Colors';

const ModalViewDetails = ({ title, path, details }) => {
    return (
        <View style={DS.ModalContentDetails}>
            <Image
                style={DS.ModalContentDetailsImage}
                source={{ uri: path || null }}
                resizeMode='cover'
            />
            <View style={{width: '50%', height: '100%', backgroundColor: Colors.shadow.a}}>
            <Text style={[DS.TextTitle, { textAlign: 'left', height: '30%' }]} ellipsizeMode='tail'>
                {title || null}
            </Text>
            <Text style={[DS.TextInfo, { height: '70%' }]} ellipsizeMode='tail'>
                {details || null}
            </Text>
            </View>
        </View>
    );
};

// Export
export default ModalViewDetails;