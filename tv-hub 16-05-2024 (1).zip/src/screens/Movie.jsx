import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Pressable,
    ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import DS from "../resources/DS";

import ModalHeader from '../modals/Header';
import {
    getNewsMoviesApi,
    getPopularMoviesApi,
} from '../api/Movie';
import IconsStyle from '../resources/IconsStyle';
import { Colors } from '../resources/Colors';

import ModalFlatlist from '../modals/Flatlist';

const Movie = () => {
    const [NewsMovies, setNewsMovies] = useState(null);
    const [PopularMovies, setMoviPopulares] = useState(null);
    
    const fetchMovies = async () => {
        let data;
        data = await getNewsMoviesApi(1);
        setNewsMovies(data.results);
        data = await getPopularMoviesApi(1);
        setMoviPopulares(data.results);
    }

    useEffect(() => {
        fetchMovies();
    }, []);

    return (
        <SafeAreaView style={DS.containerA}>
            <ModalHeader type="movie" />
            <ScrollView style={DS.containerB}>
                {/*  ==============================  */}
                <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Text style={DS.TextWhite}>
                        {`Lançamentos`}
                    </Text>
                    <Pressable onPress={() => console.log("teste")}>
                        <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                    </Pressable>
                </View>
                <ModalFlatlist data={NewsMovies} />
                {/*  ==============================  */}
                <View style={{ width: '95%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                    <Text style={DS.TextWhite}>
                        {`Populares`}
                    </Text>
                    <Pressable onPress={() => console.log("teste")}>
                        <IconsStyle name="arrowRight" size={32} color={Colors.white} />
                    </Pressable>
                </View>
                <ModalFlatlist data={PopularMovies} />
            </ScrollView>
        </SafeAreaView>
    );
};

// Export
export default Movie;