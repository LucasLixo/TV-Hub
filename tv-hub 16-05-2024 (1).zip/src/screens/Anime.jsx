import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import DS from "../resources/DS";

import ModalHeader from '../modals/Header';

const Anime = () => {

    return (
        <SafeAreaView style={DS.containerA}>
            <ModalHeader />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Anime`}</Text>
            </View>
        </SafeAreaView>
    );
};

// Export
export default Anime;