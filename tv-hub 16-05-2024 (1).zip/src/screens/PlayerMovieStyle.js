import { StyleSheet } from 'react-native';
import { Colors } from '../resources/Colors';

const Styles = StyleSheet.create({
    ImageBackdrop: {
        width: '100%',
        height: 200,
        backgroundColor: Colors.secondary
    },
    Image: {
        width: '100%',
        height: '100%',
    }
});

// Export
export default Styles;