import React from 'react';
import {
    View,
    Text,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import DS from "../resources/DS";

import ModalHeaderConfig from '../modals/HeaderConfig';

const Config = () => {

    return (
        <SafeAreaView style={DS.containerA}>
            <ModalHeaderConfig title="Configurações" />
            <View style={DS.containerB}>
                <Text style={DS.TextCenter}>{`Config`}</Text>
            </View>
        </SafeAreaView>
    );
};

// Export
export default Config;