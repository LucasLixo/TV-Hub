import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Image,
    Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import DS from "../resources/DS";

import ModalHeaderConfig from '../modals/HeaderConfig';
import { getMovieByIdApi } from '../api/Movie';
import { useRoute } from '@react-navigation/native';
import ModalToastMessage from '../modals/ShowMessage';
import { BASE_PATH_IMG } from '../resources/Constants';
import Styles from './PlayerMovieStyle';

const PlayerMovie = () => {
    const route = useRoute();
    const { idMovie } = route.params;

    const [DetailsMovie, setDetailsMovie] = useState(null);
    const [isModalToastMessage, setModalToastMessage] = useState(false);

    const fetchMovies = async () => {
        let data;
        data = await getMovieByIdApi(idMovie);
        setDetailsMovie(data);
    }

    useEffect(() => {
        fetchMovies();
    }, [idMovie]);

    return (
        <SafeAreaView style={DS.containerA}>
            <ModalHeaderConfig title={DetailsMovie ? DetailsMovie.title || DetailsMovie.original_title : ''} />
            <View style={DS.containerB}>
                <View
                    style={Styles.ImageBackdrop}
                >
                    {DetailsMovie && DetailsMovie.backdrop_path ? (
                        <Image
                            source={{ uri: `${BASE_PATH_IMG}/original${DetailsMovie.backdrop_path}` }}
                            resizeMode='cover'
                            style={Styles.Image}
                        />
                    ) : (
                        <Text style={[DS.TextCenter, Styles.Image, { fontSize: 14 }]}>
                            {DetailsMovie ? DetailsMovie.title || DetailsMovie.original_title : ''}
                        </Text>
                    )}
                </View>
                <Pressable
                    onPress={() => setModalToastMessage(!isModalToastMessage)}
                >
                    <Text style={DS.TextCenter} numberOfLines={4} ellipsizeMode='tail' >
                        {DetailsMovie ? DetailsMovie.overview : ''}
                    </Text>
                </Pressable>
            </View>
            <ModalToastMessage
                isModalVisible={isModalToastMessage}
                setModalVisible={() => setModalToastMessage(!isModalToastMessage)}
                Message={DetailsMovie ? DetailsMovie.overview : ''}
            />
        </SafeAreaView>
    );
};

// Export
export default PlayerMovie;