import React from "react";
import {
    Modal,
    Pressable,
    Text,
} from "react-native";

import Styles from "../hooks/Styles";
import Colors from "../hooks/Colors";
import { clipboardToast } from "../hooks/Fuctions";

const ShowMessage = ({ isModalVisible, setModalVisible, Message, CopyToast = true }) => {
    const handleClose = () => {
        setModalVisible();
    };

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isModalVisible}
            onRequestClose={handleClose}
        >
            <Pressable
                style={Styles.ModalContentShadow}
                onPress={() => handleClose()}
                onLongPress={() =>
                    {CopyToast && (
                        clipboardToast(Message || '')
                    )}
                }
            >
                <Text style={{ flexWrap: 'wrap', textAlign: 'center', color: Colors.text.a }}>{Message || ''}</Text>
            </Pressable>
        </Modal>
    );
};

export default ShowMessage;