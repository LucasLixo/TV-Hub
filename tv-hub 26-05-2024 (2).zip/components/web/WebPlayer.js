import React, { useRef } from 'react';
import WebView from 'react-native-webview';
import { USER_AGENT_WINDOWS, VIZER_HOST } from '../../hooks/Constants';
import Styles from '../../hooks/Styles';

const WebPlayer = ({ isUrl, isInjectedJavaScript, setHandleErro }) => {
    const WebRef = useRef(null);

    const allowedDomains = [VIZER_HOST, 'mixdrop.nu', 'streamtape.com', 'filemoon.sx'];

    const onShouldStartLoadWithRequest = (request) => {
        const url = new URL(request.url);
        return allowedDomains.includes(url.hostname);
    };

    return (
        <WebView
            ref={WebRef}
            source={{ uri: isUrl }}
            style={Styles.WebView}
            // javaScript Enabled
            javaScriptEnabled={true}
            // javaScript Can Open Window
            javaScriptCanOpenWindowsAutomatically={false}
            setSupportMultipleWindows={false}
            // dom Storage Enabled
            domStorageEnabled={true}
            // scales Page To Fit
            scalesPageToFit={false}
            // on Error
            onError={(syntheticEvent) => {
                const { nativeEvent } = syntheticEvent;
                setHandleErro(nativeEvent.description);
            }}
            injectedJavaScript={isInjectedJavaScript}
            onShouldStartLoadWithRequest={onShouldStartLoadWithRequest}
            // start In Loading State
            startInLoadingState={false}
            // userAgent
            userAgent={USER_AGENT_WINDOWS}
            // allows Protected Media
            allowsProtectedMedia={true}
            allowsFullscreenVideo={true}
            // text size android
            textZoom={100}
            // force Dark
            forceDarkOn={true}
            // Downloads
            cacheMode='LOAD_DEFAULT'
            saveFormDataDisabled={false}
            allowFileAccess={false}
            // Icognito
            incognito={false}
            // Scrool
            overScrollMode='never'
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            // enable zoom
            setBuiltInZoomControls={false}
            // load media - always
            mixedContentMode='compatibility'
        />
    );
};

// Export
export default WebPlayer;
