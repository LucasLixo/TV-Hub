import React from 'react';
import { Text, StyleSheet } from 'react-native';
import Colors from '../hooks/Colors';

const MyText = ({ text, type = 'default', style, ...rest }) => {
    const textStyles = {
        default: { color: Colors.text.a, fontSize: 14 },
        subtitle: { color: Colors.text.a, fontSize: 16, fontWeight: 'bold' },
        title: { color: Colors.sky.a, fontSize: 20, fontWeight: 'bold' }
    };

    return (
        <Text
            numberOfLines={type === 'title' ? 1 : undefined}
            ellipsizeMode={type === 'title' ? 'tail' : undefined}
            style={[textStyles[type], style]}
            {...rest}
        >
            {text}
        </Text>
    );
};

// Export
export default MyText;
